<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/navigation-desktop/navigation-desktop.twig */
class __TwigTemplate_d1353ae7ee258a405ef743007ec5435d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'top_content' => [$this, 'block_top_content'],
            'bottom_content' => [$this, 'block_bottom_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/navigation-desktop"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("navigation_desktop_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["navigation_desktop_base_class"] ?? null), 3, $this->source), "navigation-desktop")) : ("navigation-desktop"));
        // line 4
        yield "
<div ";
        // line 5
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 5, $this->source)));
        yield ">
  <div ";
        // line 6
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "top-content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 6, $this->source)));
        yield ">
    ";
        // line 7
        yield from $this->unwrap()->yieldBlock('top_content', $context, $blocks);
        // line 9
        yield "  </div>

  <div ";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "bottom-content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 11, $this->source)));
        yield ">
    ";
        // line 12
        yield from $this->unwrap()->yieldBlock('bottom_content', $context, $blocks);
        // line 14
        yield "  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["navigation_desktop_base_class"]);        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_top_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "    ";
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_bottom_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/navigation-desktop/navigation-desktop.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  103 => 13,  96 => 12,  91 => 8,  84 => 7,  76 => 14,  74 => 12,  70 => 11,  66 => 9,  64 => 7,  60 => 6,  56 => 5,  53 => 4,  51 => 3,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/navigation-desktop/navigation-desktop.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/navigation-desktop/navigation-desktop.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 7);
        static $filters = array("escape" => 1, "default" => 3);
        static $functions = array("attach_library" => 1, "bem" => 5);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block'],
                ['escape', 'default'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
