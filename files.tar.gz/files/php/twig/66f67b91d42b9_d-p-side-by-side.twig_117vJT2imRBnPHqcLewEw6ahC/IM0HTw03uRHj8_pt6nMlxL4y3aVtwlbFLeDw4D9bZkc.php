<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-side-by-side/d-p-side-by-side.twig */
class __TwigTemplate_954ee81c0e49ce8c59abc5316dab5eb8 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'heading' => [$this, 'block_heading'],
            'subheading' => [$this, 'block_subheading'],
            'content' => [$this, 'block_content'],
            'cta' => [$this, 'block_cta'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-side-by-side"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("side_by_side_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["side_by_side_base_class"] ?? null), 3, $this->source), "d-p-side-by-side")) : ("d-p-side-by-side"));
        // line 4
        $context["modifiers"] = ((array_key_exists("side_by_side_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["side_by_side_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        $context["has_heading"] =  !Twig\Extension\CoreExtension::testEmpty(Twig\Extension\CoreExtension::trim(Twig\Extension\CoreExtension::striptags($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(        $this->unwrap()->renderBlock("heading", $context, $blocks)), "<img>")));
        // line 6
        yield "
";
        // line 7
        if (($context["with_grid"] ?? null)) {
            // line 8
            yield "  ";
            $context["modifiers"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 8, $this->source), ["with-grid"]);
        }
        // line 10
        yield "
<section ";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 11, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 11, $this->source)));
        yield ">
  ";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 12, $this->source), "html", null, true);
        yield "
  ";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 13, $this->source), "html", null, true);
        yield "

  <div ";
        // line 15
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 15, $this->source), []));
        yield ">
    <div ";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "header-container", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 16, $this->source), ["container"]));
        yield ">
      <div ";
        // line 17
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "header-row", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 17, $this->source), ["row"]));
        yield ">
        <div ";
        // line 18
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "header-column", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 18, $this->source), ["col-12"]));
        yield ">
          ";
        // line 19
        if (($context["has_heading"] ?? null)) {
            // line 20
            yield "            ";
            yield from $this->unwrap()->yieldBlock('heading', $context, $blocks);
            // line 22
            yield "            ";
            yield from             $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/d-p-side-by-side/d-p-side-by-side.twig", 22)->unwrap()->yield($context);
            // line 23
            yield "          ";
        }
        // line 24
        yield "
          ";
        // line 25
        yield from $this->unwrap()->yieldBlock('subheading', $context, $blocks);
        // line 27
        yield "        </div>
      </div>
    </div>

    <div ";
        // line 31
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 31, $this->source)));
        yield ">
      <div ";
        // line 32
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-container", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 32, $this->source), ["container"]));
        yield ">
        <div ";
        // line 33
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-row", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 33, $this->source), ["row"]));
        yield ">
          ";
        // line 34
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 36
        yield "        </div>
      </div>
    </div>

    <div ";
        // line 40
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "cta-container", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 40, $this->source), ["container"]));
        yield ">
      <div ";
        // line 41
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "cta-row", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 41, $this->source), ["row"]));
        yield ">
        ";
        // line 42
        yield from $this->unwrap()->yieldBlock('cta', $context, $blocks);
        // line 44
        yield "      </div>
    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["side_by_side_base_class", "side_by_side_modifiers", "with_grid", "title_prefix", "title_suffix"]);        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_heading(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 21
        yield "            ";
        yield from [];
    }

    // line 25
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_subheading(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 26
        yield "          ";
        yield from [];
    }

    // line 34
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 35
        yield "          ";
        yield from [];
    }

    // line 42
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_cta(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 43
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-side-by-side/d-p-side-by-side.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  205 => 43,  198 => 42,  193 => 35,  186 => 34,  181 => 26,  174 => 25,  169 => 21,  162 => 20,  152 => 44,  150 => 42,  146 => 41,  142 => 40,  136 => 36,  134 => 34,  130 => 33,  126 => 32,  122 => 31,  116 => 27,  114 => 25,  111 => 24,  108 => 23,  105 => 22,  102 => 20,  100 => 19,  96 => 18,  92 => 17,  88 => 16,  84 => 15,  79 => 13,  75 => 12,  71 => 11,  68 => 10,  64 => 8,  62 => 7,  59 => 6,  57 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-side-by-side/d-p-side-by-side.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-side-by-side/d-p-side-by-side.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "if" => 7, "block" => 20, "include" => 22);
        static $filters = array("escape" => 1, "default" => 3, "trim" => 5, "striptags" => 5, "render" => 5, "merge" => 8);
        static $functions = array("attach_library" => 1, "bem" => 11);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['escape', 'default', 'trim', 'striptags', 'render', 'merge'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
