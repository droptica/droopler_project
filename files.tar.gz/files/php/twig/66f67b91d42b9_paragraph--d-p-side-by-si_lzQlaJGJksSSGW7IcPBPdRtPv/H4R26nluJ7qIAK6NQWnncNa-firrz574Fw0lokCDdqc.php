<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig */
class __TwigTemplate_44efe5710eb98734eedafe8c330d2f28 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from         $this->loadTemplate("profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig", 1, "232099496")->unwrap()->yield($context);
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig", "/var/www/html/web/profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("embed" => 1);
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['embed'],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig */
class __TwigTemplate_44efe5710eb98734eedafe8c330d2f28___232099496 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'component_content' => [$this, 'block_component_content'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@droopler_theme/templates/paragraph/paragraph.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/templates/paragraph/paragraph.html.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["paragraph", "content"]);    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_component_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        yield from         $this->loadTemplate("profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig", 4, "347785898")->unwrap()->yield(CoreExtension::merge($context, ["with_grid" => CoreExtension::getAttribute($this->env, $this->source,         // line 5
($context["paragraph"] ?? null), "enabledGrid", [], "any", false, false, true, 5), "dividers" => CoreExtension::getAttribute($this->env, $this->source,         // line 6
($context["paragraph"] ?? null), "hasDividers", [], "any", false, false, true, 6)]));
        // line 21
        yield "  ";
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 24
        yield "    ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 24, $this->source), "group_d_heading", "group_d_subheading", "group_d_content", "group_d_cta"), "html", null, true);
        yield "
  ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  161 => 24,  154 => 23,  149 => 21,  147 => 6,  146 => 5,  144 => 4,  137 => 3,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig", "/var/www/html/web/profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 1, "embed" => 4);
        static $filters = array("escape" => 24, "without" => 24);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends', 'embed'],
                ['escape', 'without'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig */
class __TwigTemplate_44efe5710eb98734eedafe8c330d2f28___347785898 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'heading' => [$this, 'block_heading'],
            'subheading' => [$this, 'block_subheading'],
            'content' => [$this, 'block_content'],
            'cta' => [$this, 'block_cta'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 4
        return "@droopler_theme/d-p-side-by-side/d-p-side-by-side.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/d-p-side-by-side/d-p-side-by-side.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig", 4);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["content"]);    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_heading(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_heading", [], "any", false, false, true, 9), 9, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_subheading(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_subheading", [], "any", false, false, true, 12), 12, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 15
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_content", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_cta(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_cta", [], "any", false, false, true, 18), 18, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  320 => 18,  313 => 17,  305 => 15,  298 => 14,  290 => 12,  283 => 11,  275 => 9,  268 => 8,  256 => 4,  161 => 24,  154 => 23,  149 => 21,  147 => 6,  146 => 5,  144 => 4,  137 => 3,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig", "/var/www/html/web/profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-side-by-side.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 4);
        static $filters = array("escape" => 9);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
