<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-banner/d-p-banner.twig */
class __TwigTemplate_02267315ba4fb2d116c2ada4a12f47a1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'background' => [$this, 'block_background'],
            'content_header' => [$this, 'block_content_header'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-banner"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("d_p_banner_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_banner_base_class"] ?? null), 3, $this->source), "d-p-banner")) : ("d-p-banner"));
        // line 4
        $context["modifiers"] = ((array_key_exists("d_p_banner_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_banner_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        $context["left_side_content"] = ((array_key_exists("left_side_content", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["left_side_content"] ?? null), 5, $this->source), false)) : (false));
        // line 6
        yield "
";
        // line 7
        if (($context["left_side_content"] ?? null)) {
            // line 8
            yield "  ";
            $context["modifiers"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 8, $this->source), ["left-side-content"]);
        }
        // line 10
        yield "
";
        // line 12
        $context["content_column_count"] = ((($context["left_side_content"] ?? null)) ? ("5") : ("12"));
        // line 13
        yield "
<section ";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 14, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 14, $this->source)));
        yield ">
  ";
        // line 15
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 15, $this->source), "html", null, true);
        yield "
  ";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 16, $this->source), "html", null, true);
        yield "
  <div ";
        // line 17
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 17, $this->source)));
        yield ">
    <div ";
        // line 18
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background-media", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 18, $this->source)));
        yield ">
      ";
        // line 19
        yield from $this->unwrap()->yieldBlock('background', $context, $blocks);
        // line 21
        yield "    </div>

    <div ";
        // line 23
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background-overlay", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 23, $this->source)));
        yield ">
      ";
        // line 24
        yield from         $this->loadTemplate("@droopler_theme/base/overlay/overlay.twig", "@droopler_theme/d-p-banner/d-p-banner.twig", 24)->unwrap()->yield($context);
        // line 25
        yield "    </div>
  </div>

  <div ";
        // line 28
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 28, $this->source), ["container", "first-child-no-spacer"]));
        yield " ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["left_side_content"] ?? null)) ? ("data-theme=\"theme-light\"") : ("")));
        yield ">
    ";
        // line 29
        if (($context["left_side_content"] ?? null)) {
            // line 30
            yield "      <div ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-overlay", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 30, $this->source)));
            yield ">
        ";
            // line 31
            yield from             $this->loadTemplate("@droopler_theme/base/overlay/overlay.twig", "@droopler_theme/d-p-banner/d-p-banner.twig", 31)->unwrap()->yield($context);
            // line 32
            yield "      </div>
    ";
        }
        // line 34
        yield "
    <div ";
        // line 35
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 35, $this->source), ["row"]));
        yield ">
      <div ";
        // line 36
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-column", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 36, $this->source), [("col-lg-" . $this->sandbox->ensureToStringAllowed(        // line 37
($context["content_column_count"] ?? null), 37, $this->source)), "col-12", "first-child-no-spacer"]));
        // line 40
        yield ">

        ";
        // line 42
        $context["has_content_header"] =  !Twig\Extension\CoreExtension::testEmpty(Twig\Extension\CoreExtension::trim(Twig\Extension\CoreExtension::striptags($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(        $this->unwrap()->renderBlock("content_header", $context, $blocks)))));
        // line 43
        yield "
        ";
        // line 44
        if (($context["has_content_header"] ?? null)) {
            // line 45
            yield "          ";
            yield from $this->unwrap()->yieldBlock('content_header', $context, $blocks);
            // line 47
            yield "          ";
            yield from             $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/d-p-banner/d-p-banner.twig", 47)->unwrap()->yield($context);
            // line 48
            yield "        ";
        }
        // line 49
        yield "
        ";
        // line 50
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 52
        yield "      </div>
    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["d_p_banner_base_class", "d_p_banner_modifiers", "title_prefix", "title_suffix"]);        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_background(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "      ";
        yield from [];
    }

    // line 45
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 46
        yield "          ";
        yield from [];
    }

    // line 50
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 51
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-banner/d-p-banner.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  207 => 51,  200 => 50,  195 => 46,  188 => 45,  183 => 20,  176 => 19,  166 => 52,  164 => 50,  161 => 49,  158 => 48,  155 => 47,  152 => 45,  150 => 44,  147 => 43,  145 => 42,  141 => 40,  139 => 37,  138 => 36,  134 => 35,  131 => 34,  127 => 32,  125 => 31,  120 => 30,  118 => 29,  112 => 28,  107 => 25,  105 => 24,  101 => 23,  97 => 21,  95 => 19,  91 => 18,  87 => 17,  83 => 16,  79 => 15,  75 => 14,  72 => 13,  70 => 12,  67 => 10,  63 => 8,  61 => 7,  58 => 6,  56 => 5,  54 => 4,  52 => 3,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-banner/d-p-banner.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-banner/d-p-banner.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "if" => 7, "block" => 19, "include" => 24);
        static $filters = array("escape" => 1, "default" => 3, "merge" => 8, "trim" => 42, "striptags" => 42, "render" => 42);
        static $functions = array("attach_library" => 1, "bem" => 14);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['escape', 'default', 'merge', 'trim', 'striptags', 'render'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
