<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig */
class __TwigTemplate_6f6608944769fecc8f30ecf799474ce5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from         $this->loadTemplate("profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig", 1, "1606245725")->unwrap()->yield($context);
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig", "/var/www/html/web/profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("embed" => 1);
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['embed'],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig */
class __TwigTemplate_6f6608944769fecc8f30ecf799474ce5___1606245725 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'component_content' => [$this, 'block_component_content'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@droopler_theme/templates/paragraph/paragraph.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/templates/paragraph/paragraph.html.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["paragraph", "content"]);    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_component_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        yield from         $this->loadTemplate("profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig", 4, "1133962733")->unwrap()->yield(CoreExtension::merge($context, ["columns" => CoreExtension::getAttribute($this->env, $this->source,         // line 5
($context["paragraph"] ?? null), "columnSettings", [], "any", false, false, true, 5), "is_full_width" => CoreExtension::getAttribute($this->env, $this->source,         // line 6
($context["paragraph"] ?? null), "fullWidth", [], "any", false, false, true, 6), "with_grid" => CoreExtension::getAttribute($this->env, $this->source,         // line 7
($context["paragraph"] ?? null), "enabledGrid", [], "any", false, false, true, 7), "with_tiles" => CoreExtension::getAttribute($this->env, $this->source,         // line 8
($context["paragraph"] ?? null), "enabledTiles", [], "any", false, false, true, 8), "header_into_columns" => CoreExtension::getAttribute($this->env, $this->source,         // line 9
($context["paragraph"] ?? null), "headerIntoColumns", [], "any", false, false, true, 9)]));
        // line 27
        yield "  ";
        yield from [];
    }

    // line 29
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 30
        yield "    ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 30, $this->source), "group_d_header", "group_d_body_text", "group_d_text_blocks_reference", "group_d_text_blocks_cta"), "html", null, true);
        yield "
  ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  164 => 30,  157 => 29,  152 => 27,  150 => 9,  149 => 8,  148 => 7,  147 => 6,  146 => 5,  144 => 4,  137 => 3,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig", "/var/www/html/web/profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 1, "embed" => 4);
        static $filters = array("escape" => 30, "without" => 30);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends', 'embed'],
                ['escape', 'without'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig */
class __TwigTemplate_6f6608944769fecc8f30ecf799474ce5___1133962733 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'body_content' => [$this, 'block_body_content'],
            'items' => [$this, 'block_items'],
            'cta' => [$this, 'block_cta'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 4
        return "@droopler_theme/d-p-group-of-text-blocks/d-p-group-of-text-blocks.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/d-p-group-of-text-blocks/d-p-group-of-text-blocks.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig", 4);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["content"]);    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_header", [], "any", false, false, true, 12), 12, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 16
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_body_text", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_text_blocks_reference", [], "any", false, false, true, 20), 20, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_cta(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 24
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_text_blocks_cta", [], "any", false, false, true, 24), 24, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  323 => 24,  316 => 23,  308 => 20,  301 => 19,  293 => 16,  286 => 15,  278 => 12,  271 => 11,  259 => 4,  164 => 30,  157 => 29,  152 => 27,  150 => 9,  149 => 8,  148 => 7,  147 => 6,  146 => 5,  144 => 4,  137 => 3,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig", "/var/www/html/web/profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-group-of-text-blocks.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 4);
        static $filters = array("escape" => 12);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
