<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-single-text-block/d-p-single-text-block--side-by-side.twig */
class __TwigTemplate_f08d8ce7fffee2f9e212c5ef22cf1676 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'background' => [$this, 'block_background'],
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-single-text-block"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("d_p_single_text_blocks_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_single_text_blocks_base_class"] ?? null), 3, $this->source), "d-p-single-text-block")) : ("d-p-single-text-block"));
        // line 4
        $context["modifiers"] = Twig\Extension\CoreExtension::merge(((array_key_exists("d_p_single_text_blocks_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_single_text_blocks_modifiers"] ?? null), 4, $this->source), [])) : ([])), [((        // line 5
($context["has_background"] ?? null)) ? ("has-media-background") : (""))]);
        // line 7
        $context["additional_classes"] = ((array_key_exists("d_p_single_text_block_additional_classes", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_single_text_block_additional_classes"] ?? null), 7, $this->source), [])) : ([]));
        // line 8
        $context["styles"] = Twig\Extension\CoreExtension::join($this->sandbox->ensureToStringAllowed(($context["customTheme"] ?? null), 8, $this->source), ";");
        // line 9
        yield "
<div ";
        // line 10
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 10, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 10, $this->source), "", $this->sandbox->ensureToStringAllowed(($context["additional_classes"] ?? null), 10, $this->source)));
        yield " style=\"";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["styles"] ?? null), 10, $this->source), "html", null, true);
        yield "\">
  ";
        // line 11
        yield from $this->unwrap()->yieldBlock('background', $context, $blocks);
        // line 13
        yield "
  <div ";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 14, $this->source)));
        yield ">
    ";
        // line 15
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 17
        yield "
    ";
        // line 18
        yield from         $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/d-p-single-text-block/d-p-single-text-block--side-by-side.twig", 18)->unwrap()->yield($context);
        // line 19
        yield "
    ";
        // line 20
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 22
        yield "  </div>

  ";
        // line 24
        if (($context["with_price"] ?? null)) {
            // line 25
            yield "    ";
            yield from             $this->loadTemplate("@droopler_theme/price-block/price-block.twig", "@droopler_theme/d-p-single-text-block/d-p-single-text-block--side-by-side.twig", 25)->unwrap()->yield(CoreExtension::merge($context, ["sidebar" =>             // line 26
($context["with_price_in_sidebar"] ?? null)]));
            // line 28
            yield "  ";
        }
        // line 29
        yield "</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["d_p_single_text_blocks_base_class", "d_p_single_text_blocks_modifiers", "has_background", "d_p_single_text_block_additional_classes", "customTheme", "with_price", "with_price_in_sidebar"]);        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_background(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "  ";
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 16
        yield "    ";
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 21
        yield "    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-single-text-block/d-p-single-text-block--side-by-side.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  142 => 21,  135 => 20,  130 => 16,  123 => 15,  118 => 12,  111 => 11,  104 => 29,  101 => 28,  99 => 26,  97 => 25,  95 => 24,  91 => 22,  89 => 20,  86 => 19,  84 => 18,  81 => 17,  79 => 15,  75 => 14,  72 => 13,  70 => 11,  64 => 10,  61 => 9,  59 => 8,  57 => 7,  55 => 5,  54 => 4,  52 => 3,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-single-text-block/d-p-single-text-block--side-by-side.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-single-text-block/d-p-single-text-block--side-by-side.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 11, "include" => 18, "if" => 24);
        static $filters = array("escape" => 1, "default" => 3, "merge" => 4, "join" => 8);
        static $functions = array("attach_library" => 1, "bem" => 10);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'include', 'if'],
                ['escape', 'default', 'merge', 'join'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
