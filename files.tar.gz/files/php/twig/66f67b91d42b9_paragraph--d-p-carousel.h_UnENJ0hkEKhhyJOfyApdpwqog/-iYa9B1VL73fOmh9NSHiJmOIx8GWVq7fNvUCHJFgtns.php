<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig */
class __TwigTemplate_9d0d2ed08a1f24513f433713e1775d9f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from         $this->loadTemplate("profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig", 1, "1940774164")->unwrap()->yield($context);
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig", "/var/www/html/web/profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("embed" => 1);
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['embed'],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig */
class __TwigTemplate_9d0d2ed08a1f24513f433713e1775d9f___1940774164 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'component_content' => [$this, 'block_component_content'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@droopler_theme/templates/paragraph/paragraph.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/templates/paragraph/paragraph.html.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["paragraph", "content"]);    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_component_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        yield from         $this->loadTemplate("profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig", 4, "1080793755")->unwrap()->yield(CoreExtension::merge($context, ["is_full_width" => CoreExtension::getAttribute($this->env, $this->source,         // line 5
($context["paragraph"] ?? null), "fullWidth", [], "any", false, false, true, 5), "carousel_settings" => CoreExtension::getAttribute($this->env, $this->source,         // line 6
($context["paragraph"] ?? null), "carouselSettings", [], "any", false, false, true, 6), "dividers" => CoreExtension::getAttribute($this->env, $this->source,         // line 7
($context["paragraph"] ?? null), "hasDividers", [], "any", false, false, true, 7)]));
        // line 22
        yield "  ";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        yield "    ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 25, $this->source), "group_d_heading", "group_d_subheading", "group_d_content", "group_d_cta"), "html", null, true);
        yield "
  ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  162 => 25,  155 => 24,  150 => 22,  148 => 7,  147 => 6,  146 => 5,  144 => 4,  137 => 3,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig", "/var/www/html/web/profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 1, "embed" => 4);
        static $filters = array("escape" => 25, "without" => 25);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends', 'embed'],
                ['escape', 'without'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig */
class __TwigTemplate_9d0d2ed08a1f24513f433713e1775d9f___1080793755 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'heading' => [$this, 'block_heading'],
            'subheading' => [$this, 'block_subheading'],
            'content' => [$this, 'block_content'],
            'cta' => [$this, 'block_cta'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 4
        return "@droopler_theme/d-p-carousel/d-p-carousel.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/d-p-carousel/d-p-carousel.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig", 4);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["content"]);    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_heading(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_heading", [], "any", false, false, true, 10), 10, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_subheading(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_subheading", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 16
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_content", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_cta(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 19
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_cta", [], "any", false, false, true, 19), 19, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  321 => 19,  314 => 18,  306 => 16,  299 => 15,  291 => 13,  284 => 12,  276 => 10,  269 => 9,  257 => 4,  162 => 25,  155 => 24,  150 => 22,  148 => 7,  147 => 6,  146 => 5,  144 => 4,  137 => 3,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig", "/var/www/html/web/profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-carousel.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 4);
        static $filters = array("escape" => 10);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
