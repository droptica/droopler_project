<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-group-of-text-blocks/d-p-group-of-text-blocks.twig */
class __TwigTemplate_29b747b6ae2a2971bb62e202dce7a309 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'body_content' => [$this, 'block_body_content'],
            'items' => [$this, 'block_items'],
            'cta' => [$this, 'block_cta'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-group-of-text-blocks"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("d_p_group_of_text_blocks_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_group_of_text_blocks_base_class"] ?? null), 3, $this->source), "d-p-group-of-text-blocks")) : ("d-p-group-of-text-blocks"));
        // line 4
        $context["modifiers"] = ((array_key_exists("d_p_group_of_text_blocks_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_group_of_text_blocks_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        yield "
";
        // line 6
        if (($context["with_grid"] ?? null)) {
            // line 7
            yield "  ";
            $context["modifiers"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 7, $this->source), ["with-grid"]);
        }
        // line 9
        yield "
";
        // line 10
        if (($context["with_tiles"] ?? null)) {
            // line 11
            yield "  ";
            $context["modifiers"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 11, $this->source), ["with-tiles"]);
        }
        // line 13
        yield "
";
        // line 14
        $context["items_classes"] = ["row", ((CoreExtension::getAttribute($this->env, $this->source,         // line 16
($context["columns"] ?? null), "column_count_desktop", [], "any", false, false, true, 16)) ? (("row-cols-lg-" . $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "column_count_desktop", [], "any", false, false, true, 16), 16, $this->source))) : ("")), ((CoreExtension::getAttribute($this->env, $this->source,         // line 17
($context["columns"] ?? null), "column_count_tablet", [], "any", false, false, true, 17)) ? (("row-cols-md-" . $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "column_count_tablet", [], "any", false, false, true, 17), 17, $this->source))) : ("")), ((CoreExtension::getAttribute($this->env, $this->source,         // line 18
($context["columns"] ?? null), "column_count_mobile", [], "any", false, false, true, 18)) ? (("row-cols-" . $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "column_count_mobile", [], "any", false, false, true, 18), 18, $this->source))) : (""))];
        // line 20
        yield "
";
        // line 21
        $context["has_header"] =  !Twig\Extension\CoreExtension::testEmpty(Twig\Extension\CoreExtension::trim(Twig\Extension\CoreExtension::striptags($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(        $this->unwrap()->renderBlock("header", $context, $blocks)))));
        // line 22
        $context["header_column_classes"] = [((($context["header_into_columns"] ?? null)) ? ("col-md-6") : ("col-12"))];
        // line 23
        yield "
<section ";
        // line 24
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 24, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 24, $this->source)));
        yield ">
  ";
        // line 25
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 25, $this->source), "html", null, true);
        yield "
  ";
        // line 26
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 26, $this->source), "html", null, true);
        yield "

  <div ";
        // line 28
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 28, $this->source)));
        yield ">
    <div ";
        // line 29
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "header", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 29, $this->source), ["container"]));
        yield ">
      <div ";
        // line 30
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "header-wrapper", [((($context["header_into_columns"] ?? null)) ? ("columns") : ("single"))], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 30, $this->source), ["row"]));
        yield ">
        ";
        // line 31
        if (($context["has_header"] ?? null)) {
            // line 32
            yield "          <div ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "header-column", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 32, $this->source), $this->sandbox->ensureToStringAllowed(($context["header_column_classes"] ?? null), 32, $this->source)));
            yield ">
            ";
            // line 33
            yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
            // line 35
            yield "
            ";
            // line 36
            yield from             $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/d-p-group-of-text-blocks/d-p-group-of-text-blocks.twig", 36)->unwrap()->yield($context);
            // line 37
            yield "          </div>
        ";
        }
        // line 39
        yield "        <div ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "header-column", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 39, $this->source), $this->sandbox->ensureToStringAllowed(($context["header_column_classes"] ?? null), 39, $this->source)));
        yield ">
          <div ";
        // line 40
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "body-content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 40, $this->source)));
        yield ">
            ";
        // line 41
        yield from $this->unwrap()->yieldBlock('body_content', $context, $blocks);
        // line 43
        yield "          </div>
        </div>
      </div>
    </div>

    <div ";
        // line 48
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "items", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 48, $this->source), [((($context["is_full_width"] ?? null)) ? ("container-fluid") : ("container"))]));
        yield ">
      <div ";
        // line 49
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "items-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 49, $this->source), $this->sandbox->ensureToStringAllowed(($context["items_classes"] ?? null), 49, $this->source)));
        yield ">
        ";
        // line 50
        yield from $this->unwrap()->yieldBlock('items', $context, $blocks);
        // line 52
        yield "      </div>
    </div>

    <div ";
        // line 55
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "footer", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 55, $this->source), ["container"]));
        yield ">
      <div ";
        // line 56
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "footer-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 56, $this->source), ["row"]));
        yield ">
        <div ";
        // line 57
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "footer-column", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 57, $this->source), ["col-12"]));
        yield ">
          ";
        // line 58
        yield from $this->unwrap()->yieldBlock('cta', $context, $blocks);
        // line 60
        yield "        </div>
      </div>
    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["d_p_group_of_text_blocks_base_class", "d_p_group_of_text_blocks_modifiers", "with_grid", "with_tiles", "columns", "header_into_columns", "title_prefix", "title_suffix", "is_full_width"]);        yield from [];
    }

    // line 33
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 34
        yield "            ";
        yield from [];
    }

    // line 41
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 42
        yield "            ";
        yield from [];
    }

    // line 50
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 51
        yield "        ";
        yield from [];
    }

    // line 58
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_cta(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 59
        yield "          ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-group-of-text-blocks/d-p-group-of-text-blocks.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  237 => 59,  230 => 58,  225 => 51,  218 => 50,  213 => 42,  206 => 41,  201 => 34,  194 => 33,  183 => 60,  181 => 58,  177 => 57,  173 => 56,  169 => 55,  164 => 52,  162 => 50,  158 => 49,  154 => 48,  147 => 43,  145 => 41,  141 => 40,  136 => 39,  132 => 37,  130 => 36,  127 => 35,  125 => 33,  120 => 32,  118 => 31,  114 => 30,  110 => 29,  106 => 28,  101 => 26,  97 => 25,  93 => 24,  90 => 23,  88 => 22,  86 => 21,  83 => 20,  81 => 18,  80 => 17,  79 => 16,  78 => 14,  75 => 13,  71 => 11,  69 => 10,  66 => 9,  62 => 7,  60 => 6,  57 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-group-of-text-blocks/d-p-group-of-text-blocks.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-group-of-text-blocks/d-p-group-of-text-blocks.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "if" => 6, "block" => 33, "include" => 36);
        static $filters = array("escape" => 1, "default" => 3, "merge" => 7, "trim" => 21, "striptags" => 21, "render" => 21);
        static $functions = array("attach_library" => 1, "bem" => 24);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['escape', 'default', 'merge', 'trim', 'striptags', 'render'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
