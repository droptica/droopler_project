<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-carousel-item/d-p-carousel-item.twig */
class __TwigTemplate_e1f1e1797c2775e020f8ec124f29a825 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'description' => [$this, 'block_description'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-carousel-item"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("d_p_carousel_item_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_carousel_item_base_class"] ?? null), 3, $this->source), "d-p-carousel-item")) : ("d-p-carousel-item"));
        // line 4
        $context["modifiers"] = ((array_key_exists("d_p_carousel_item_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_carousel_item_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        $context["link"] = ((array_key_exists("d_p_carousel_item_link", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_carousel_item_link"] ?? null), 5, $this->source), "")) : (""));
        // line 6
        yield "
<div ";
        // line 7
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 7, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 7, $this->source)));
        yield " ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(((($context["link"] ?? null)) ? ("data-has-link") : ("")));
        yield ">
  ";
        // line 8
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 8, $this->source), "html", null, true);
        yield "
  ";
        // line 9
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 9, $this->source), "html", null, true);
        yield "

  <div ";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 11, $this->source)));
        yield ">
    ";
        // line 12
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 14
        yield "
    ";
        // line 15
        $context["has_description"] =  !Twig\Extension\CoreExtension::testEmpty(Twig\Extension\CoreExtension::trim(Twig\Extension\CoreExtension::striptags($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(        $this->unwrap()->renderBlock("description", $context, $blocks)))));
        // line 16
        yield "
    ";
        // line 17
        if (($context["has_description"] ?? null)) {
            // line 18
            yield "      ";
            yield from             $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/d-p-carousel-item/d-p-carousel-item.twig", 18)->unwrap()->yield($context);
            // line 19
            yield "      
      ";
            // line 20
            yield from $this->unwrap()->yieldBlock('description', $context, $blocks);
            // line 22
            yield "    ";
        }
        // line 23
        yield "
    ";
        // line 24
        if (($context["link"] ?? null)) {
            // line 25
            yield "      <a ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "link", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 25, $this->source)));
            yield " href=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["link"] ?? null), 25, $this->source), "html", null, true);
            yield "\"></a>
    ";
        }
        // line 27
        yield "  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["d_p_carousel_item_base_class", "d_p_carousel_item_modifiers", "d_p_carousel_item_link", "title_prefix", "title_suffix"]);        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "    ";
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_description(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 21
        yield "      ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-carousel-item/d-p-carousel-item.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  142 => 21,  135 => 20,  130 => 13,  123 => 12,  115 => 27,  107 => 25,  105 => 24,  102 => 23,  99 => 22,  97 => 20,  94 => 19,  91 => 18,  89 => 17,  86 => 16,  84 => 15,  81 => 14,  79 => 12,  75 => 11,  70 => 9,  66 => 8,  60 => 7,  57 => 6,  55 => 5,  53 => 4,  51 => 3,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-carousel-item/d-p-carousel-item.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-carousel-item/d-p-carousel-item.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 12, "if" => 17, "include" => 18);
        static $filters = array("escape" => 1, "default" => 3, "trim" => 15, "striptags" => 15, "render" => 15);
        static $functions = array("attach_library" => 1, "bem" => 7);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if', 'include'],
                ['escape', 'default', 'trim', 'striptags', 'render'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
