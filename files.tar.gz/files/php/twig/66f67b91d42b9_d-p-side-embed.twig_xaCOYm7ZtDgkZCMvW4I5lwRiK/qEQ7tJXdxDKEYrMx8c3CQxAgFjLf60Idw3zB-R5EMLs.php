<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-side-embed/d-p-side-embed.twig */
class __TwigTemplate_cda48b9a09184e45c8863f0d12492e2b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'embed' => [$this, 'block_embed'],
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-side-embed"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("d_p_side_embed_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_side_embed_base_class"] ?? null), 3, $this->source), "d-p-side-embed")) : ("d-p-side-embed"));
        // line 4
        $context["modifiers"] = ((array_key_exists("d_p_side_embed_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_side_embed_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        $context["embed_side"] = "left";
        // line 6
        yield "
";
        // line 7
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["paragraph"] ?? null), "getEmbedSide", [], "any", false, false, true, 7)) {
            // line 8
            yield "  ";
            $context["modifiers"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 8, $this->source), [("embed-" . $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["paragraph"] ?? null), "getEmbedSide", [], "any", false, false, true, 8), 8, $this->source))]);
            // line 9
            yield "  ";
            $context["embed_side"] = CoreExtension::getAttribute($this->env, $this->source, ($context["paragraph"] ?? null), "getEmbedSide", [], "any", false, false, true, 9);
        }
        // line 11
        yield "
<section ";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 12, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 12, $this->source)));
        yield ">
  ";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 13, $this->source), "html", null, true);
        yield "
  ";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 14, $this->source), "html", null, true);
        yield "

  <div ";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "embed", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 16, $this->source)));
        yield ">
    ";
        // line 17
        yield from $this->unwrap()->yieldBlock('embed', $context, $blocks);
        // line 19
        yield "  </div>

  <div ";
        // line 21
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 21, $this->source), ["container"]));
        yield ">
    <div ";
        // line 22
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 22, $this->source), ["row"]));
        yield ">
      <div ";
        // line 23
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-column", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 23, $this->source), ["col-md-6", (((($context["embed_side"] ?? null) == "left")) ? ("offset-md-6") : (""))]));
        yield ">
        ";
        // line 24
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 26
        yield "
        ";
        // line 27
        yield from         $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/d-p-side-embed/d-p-side-embed.twig", 27)->unwrap()->yield($context);
        // line 28
        yield "
        ";
        // line 29
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 31
        yield "      </div>
    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["d_p_side_embed_base_class", "d_p_side_embed_modifiers", "paragraph", "title_prefix", "title_suffix"]);        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_embed(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        yield "    ";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        yield "        ";
        yield from [];
    }

    // line 29
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 30
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-side-embed/d-p-side-embed.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  161 => 30,  154 => 29,  149 => 25,  142 => 24,  137 => 18,  130 => 17,  120 => 31,  118 => 29,  115 => 28,  113 => 27,  110 => 26,  108 => 24,  104 => 23,  100 => 22,  96 => 21,  92 => 19,  90 => 17,  86 => 16,  81 => 14,  77 => 13,  73 => 12,  70 => 11,  66 => 9,  63 => 8,  61 => 7,  58 => 6,  56 => 5,  54 => 4,  52 => 3,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-side-embed/d-p-side-embed.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-side-embed/d-p-side-embed.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "if" => 7, "block" => 17, "include" => 27);
        static $filters = array("escape" => 1, "default" => 3, "merge" => 8);
        static $functions = array("attach_library" => 1, "bem" => 12);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['escape', 'default', 'merge'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
