<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/reference-content/reference-content.twig */
class __TwigTemplate_08eb2d838d4d8f40052bb0fd0f0c72fa extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'image' => [$this, 'block_image'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/reference-content"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("reference_content_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["reference_content_base_class"] ?? null), 3, $this->source), "reference-content")) : ("reference-content"));
        // line 4
        $context["modifiers"] = ((array_key_exists("reference_content_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["reference_content_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        yield "
<article ";
        // line 6
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 6, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 6, $this->source), "", ["col-sm-6", "col-lg-3"]));
        yield ">
  ";
        // line 7
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 7, $this->source), "html", null, true);
        yield "
  ";
        // line 8
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 8, $this->source), "html", null, true);
        yield "

    <div ";
        // line 10
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "image", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 10, $this->source)));
        yield ">
      <a href=\"";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["url"] ?? null), 11, $this->source), "html", null, true);
        yield "\">
        ";
        // line 12
        yield from $this->unwrap()->yieldBlock('image', $context, $blocks);
        // line 14
        yield "      </a>
    </div>
  <div ";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "teaser", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 16, $this->source)));
        yield ">
    <a href=\"";
        // line 17
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["url"] ?? null), 17, $this->source), "html", null, true);
        yield "\">
      ";
        // line 18
        yield from         $this->loadTemplate("@droopler_theme/base/heading/heading.twig", "@droopler_theme/reference-content/reference-content.twig", 18)->unwrap()->yield(CoreExtension::merge($context, ["heading_tag" => "h2", "label" =>         // line 20
($context["label"] ?? null)]));
        // line 22
        yield "    </a>

    ";
        // line 24
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 26
        yield "
    ";
        // line 27
        yield from         $this->loadTemplate("@droopler_theme/reference-content/reference-content.twig", "@droopler_theme/reference-content/reference-content.twig", 27, "106498280")->unwrap()->yield($context);
        // line 32
        yield "  </div>
</article>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["reference_content_base_class", "reference_content_modifiers", "title_prefix", "title_suffix", "url", "label"]);        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_image(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "        ";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        yield "    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/reference-content/reference-content.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  134 => 25,  127 => 24,  122 => 13,  115 => 12,  107 => 32,  105 => 27,  102 => 26,  100 => 24,  96 => 22,  94 => 20,  93 => 18,  89 => 17,  85 => 16,  81 => 14,  79 => 12,  75 => 11,  71 => 10,  66 => 8,  62 => 7,  58 => 6,  55 => 5,  53 => 4,  51 => 3,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/reference-content/reference-content.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/reference-content/reference-content.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 12, "include" => 18, "embed" => 27);
        static $filters = array("escape" => 1, "default" => 3);
        static $functions = array("attach_library" => 1, "bem" => 6);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'include', 'embed'],
                ['escape', 'default'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* @droopler_theme/reference-content/reference-content.twig */
class __TwigTemplate_08eb2d838d4d8f40052bb0fd0f0c72fa___106498280 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'links' => [$this, 'block_links'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 27
        return "@droopler_theme/cta-links/cta-links.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/cta-links/cta-links.twig", "@droopler_theme/reference-content/reference-content.twig", 27);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["url"]);    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_links(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 29
        yield "        <a href=\"";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["url"] ?? null), 29, $this->source), "html", null, true);
        yield "\">Learn more</a>
      ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/reference-content/reference-content.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  242 => 29,  235 => 28,  223 => 27,  134 => 25,  127 => 24,  122 => 13,  115 => 12,  107 => 32,  105 => 27,  102 => 26,  100 => 24,  96 => 22,  94 => 20,  93 => 18,  89 => 17,  85 => 16,  81 => 14,  79 => 12,  75 => 11,  71 => 10,  66 => 8,  62 => 7,  58 => 6,  55 => 5,  53 => 4,  51 => 3,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/reference-content/reference-content.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/reference-content/reference-content.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 27);
        static $filters = array("escape" => 29);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
