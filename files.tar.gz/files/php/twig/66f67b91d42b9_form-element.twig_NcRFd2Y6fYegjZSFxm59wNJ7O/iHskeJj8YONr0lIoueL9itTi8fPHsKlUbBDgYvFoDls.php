<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @radix/form/form-element.twig */
class __TwigTemplate_cedd1c748a08643077f2e55632e5281a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 49
        $context["utility_classes"] = ((($context["utility_classes"] ?? null)) ? (($context["utility_classes"] ?? null)) : ([]));
        // line 50
        yield "
";
        // line 52
        $context["classes"] = Twig\Extension\CoreExtension::merge(["js-form-item", "form-item", ("form-type-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(        // line 55
($context["type"] ?? null), 55, $this->source))), ("js-form-type-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(        // line 56
($context["type"] ?? null), 56, $this->source))), ("form-item-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(        // line 57
($context["name"] ?? null), 57, $this->source))), ("js-form-item-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(        // line 58
($context["name"] ?? null), 58, $this->source))), ((!CoreExtension::inFilter(        // line 59
($context["title_display"] ?? null), ["after", "before"])) ? ("form-no-label") : ("")), (((        // line 60
($context["disabled"] ?? null) == "disabled")) ? ("form-disabled disabled") : ("")), ((        // line 61
($context["errors"] ?? null)) ? ("form-item--error has-error") : ("")), "form-group"], $this->sandbox->ensureToStringAllowed(        // line 63
($context["utility_classes"] ?? null), 63, $this->source));
        // line 66
        $context["description_classes"] = ["description", "form-text", "text-muted", (((        // line 70
($context["description_display"] ?? null) == "invisible")) ? ("visually-hidden") : (""))];
        // line 73
        yield "<div";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 73), 73, $this->source), "html", null, true);
        yield ">
  ";
        // line 74
        if (CoreExtension::inFilter(($context["label_display"] ?? null), ["before", "invisible"])) {
            // line 75
            yield "    ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["label"] ?? null), 75, $this->source), "html", null, true);
            yield "
  ";
        }
        // line 77
        yield "
  ";
        // line 78
        if (( !Twig\Extension\CoreExtension::testEmpty(($context["prefix"] ?? null)) ||  !Twig\Extension\CoreExtension::testEmpty(($context["suffix"] ?? null)))) {
            // line 79
            yield "    <div class=\"input-group\">
  ";
        }
        // line 81
        yield "
  ";
        // line 82
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["prefix"] ?? null))) {
            // line 83
            yield "    <span class=\"field-prefix input-group-text\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["prefix"] ?? null), 83, $this->source), "html", null, true);
            yield "</span>
  ";
        }
        // line 85
        yield "
  ";
        // line 86
        if (((($context["description_display"] ?? null) == "before") && CoreExtension::getAttribute($this->env, $this->source, ($context["description"] ?? null), "content", [], "any", false, false, true, 86))) {
            // line 87
            yield "    <div";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["description"] ?? null), "attributes", [], "any", false, false, true, 87), 87, $this->source), "html", null, true);
            yield ">
      ";
            // line 88
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["description"] ?? null), "content", [], "any", false, false, true, 88), 88, $this->source), "html", null, true);
            yield "
    </div>
  ";
        }
        // line 91
        yield "
  ";
        // line 92
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["children"] ?? null), 92, $this->source), "html", null, true);
        yield "

  ";
        // line 94
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["suffix"] ?? null))) {
            // line 95
            yield "    <span class=\"field-suffix input-group-text\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["suffix"] ?? null), 95, $this->source), "html", null, true);
            yield "</span>
  ";
        }
        // line 97
        yield "
  ";
        // line 98
        if (( !Twig\Extension\CoreExtension::testEmpty(($context["prefix"] ?? null)) ||  !Twig\Extension\CoreExtension::testEmpty(($context["suffix"] ?? null)))) {
            // line 99
            yield "    </div>
  ";
        }
        // line 101
        yield "
  ";
        // line 102
        if ((($context["label_display"] ?? null) == "after")) {
            // line 103
            yield "    ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["label"] ?? null), 103, $this->source), "html", null, true);
            yield "
  ";
        }
        // line 105
        yield "
  ";
        // line 106
        if (($context["errors"] ?? null)) {
            // line 107
            yield "    <div class=\"invalid-feedback\">
      ";
            // line 108
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["errors"] ?? null), 108, $this->source), "html", null, true);
            yield "
    </div>
  ";
        }
        // line 111
        yield "
  ";
        // line 112
        if ((CoreExtension::inFilter(($context["description_display"] ?? null), ["after", "invisible"]) && CoreExtension::getAttribute($this->env, $this->source, ($context["description"] ?? null), "content", [], "any", false, false, true, 112))) {
            // line 113
            yield "    <small";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["description"] ?? null), "attributes", [], "any", false, false, true, 113), "addClass", [($context["description_classes"] ?? null)], "method", false, false, true, 113), 113, $this->source), "html", null, true);
            yield ">
      ";
            // line 114
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["description"] ?? null), "content", [], "any", false, false, true, 114), 114, $this->source), "html", null, true);
            yield "
    </small>
  ";
        }
        // line 117
        yield "</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["type", "name", "title_display", "disabled", "errors", "description_display", "attributes", "label_display", "label", "prefix", "suffix", "description", "children"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@radix/form/form-element.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  177 => 117,  171 => 114,  166 => 113,  164 => 112,  161 => 111,  155 => 108,  152 => 107,  150 => 106,  147 => 105,  141 => 103,  139 => 102,  136 => 101,  132 => 99,  130 => 98,  127 => 97,  121 => 95,  119 => 94,  114 => 92,  111 => 91,  105 => 88,  100 => 87,  98 => 86,  95 => 85,  89 => 83,  87 => 82,  84 => 81,  80 => 79,  78 => 78,  75 => 77,  69 => 75,  67 => 74,  62 => 73,  60 => 70,  59 => 66,  57 => 63,  56 => 61,  55 => 60,  54 => 59,  53 => 58,  52 => 57,  51 => 56,  50 => 55,  49 => 52,  46 => 50,  44 => 49,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@radix/form/form-element.twig", "themes/contrib/radix/src/components/form/form-element.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 49, "if" => 74);
        static $filters = array("merge" => 63, "clean_class" => 55, "escape" => 73);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['merge', 'clean_class', 'escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
