<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-single-text-block--in-side-by-side.html.twig */
class __TwigTemplate_4d2b86270c484670d4b26add5a6fecee extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from         $this->loadTemplate("profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-single-text-block--in-side-by-side.html.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-single-text-block--in-side-by-side.html.twig", 1, "549278418")->unwrap()->yield(CoreExtension::merge($context, ["has_background" => CoreExtension::getAttribute($this->env, $this->source,         // line 2
($context["paragraph"] ?? null), "mediaBackground", [], "any", false, false, true, 2), "with_price" => CoreExtension::getAttribute($this->env, $this->source,         // line 3
($context["paragraph"] ?? null), "enabledPrice", [], "any", false, false, true, 3), "with_price_in_sidebar" => CoreExtension::getAttribute($this->env, $this->source,         // line 4
($context["paragraph"] ?? null), "priceInSidebar", [], "any", false, false, true, 4), "d_p_single_text_blocks_modifiers" => ["in-side-by-side"]]));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["paragraph"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-single-text-block--in-side-by-side.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  47 => 4,  46 => 3,  45 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-single-text-block--in-side-by-side.html.twig", "/var/www/html/web/profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-single-text-block--in-side-by-side.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("embed" => 1);
        static $filters = array();
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['embed'],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-single-text-block--in-side-by-side.html.twig */
class __TwigTemplate_4d2b86270c484670d4b26add5a6fecee___549278418 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'background' => [$this, 'block_background'],
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@droopler_theme/d-p-single-text-block/d-p-single-text-block--side-by-side.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/d-p-single-text-block/d-p-single-text-block--side-by-side.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-single-text-block--in-side-by-side.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["content"]);    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_background(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "    ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_block_background", [], "any", false, false, true, 8), 8, $this->source), "html", null, true);
        yield "
  ";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "    ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_header", [], "any", false, false, true, 12), 12, $this->source), "html", null, true);
        yield "
  ";
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 16
        yield "    ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "group_d_block_content", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
        yield "
  ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-single-text-block--in-side-by-side.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  188 => 16,  181 => 15,  173 => 12,  166 => 11,  158 => 8,  151 => 7,  139 => 1,  47 => 4,  46 => 3,  45 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-single-text-block--in-side-by-side.html.twig", "/var/www/html/web/profiles/contrib/droopler/themes/custom/droopler_theme/templates/paragraph/paragraph--d-p-single-text-block--in-side-by-side.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 1);
        static $filters = array("escape" => 8);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
