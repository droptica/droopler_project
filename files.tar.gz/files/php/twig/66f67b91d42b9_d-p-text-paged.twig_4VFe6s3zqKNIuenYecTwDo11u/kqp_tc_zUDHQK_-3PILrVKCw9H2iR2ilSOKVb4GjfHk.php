<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-text-paged/d-p-text-paged.twig */
class __TwigTemplate_be7ba8e103d32d85f414949b400e73f4 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'background' => [$this, 'block_background'],
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
            'cta' => [$this, 'block_cta'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-text-paged"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("d_p_text_paged_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_text_paged_base_class"] ?? null), 3, $this->source), "d-p-text-paged")) : ("d-p-text-paged"));
        // line 4
        $context["modifiers"] = ((array_key_exists("d_p_text_paged_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_text_paged_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        $context["additional_classes"] = ((array_key_exists("additional_classes", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["additional_classes"] ?? null), 5, $this->source), [])) : ([]));
        // line 6
        $context["component_attributes"] = ((array_key_exists("component_attributes", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["component_attributes"] ?? null), 6, $this->source), [])) : ([]));
        // line 7
        yield "
";
        // line 8
        $context["content_wrapper_additiona_classes"] = ["row"];
        // line 9
        if (((($context["text_align"] ?? null) == "center") || (($context["text_align"] ?? null) == "end"))) {
            // line 10
            yield "  ";
            $context["content_wrapper_additiona_classes"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["content_wrapper_additiona_classes"] ?? null), 10, $this->source), [("justify-content-" . $this->sandbox->ensureToStringAllowed(($context["text_align"] ?? null), 10, $this->source))]);
        }
        // line 12
        yield "
";
        // line 13
        $context["content_additional_classes"] = [(((($__internal_compile_0 =         // line 14
($context["columns"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["column_count_desktop"] ?? null) : null)) ? (("col-lg-" . $this->sandbox->ensureToStringAllowed((($__internal_compile_1 = ($context["columns"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["column_count_desktop"] ?? null) : null), 14, $this->source))) : ("")), (((($__internal_compile_2 =         // line 15
($context["columns"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["column_count_tablet"] ?? null) : null)) ? (("col-sm-" . $this->sandbox->ensureToStringAllowed((($__internal_compile_3 = ($context["columns"] ?? null)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3["column_count_tablet"] ?? null) : null), 15, $this->source))) : ("")), (((($__internal_compile_4 =         // line 16
($context["columns"] ?? null)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["column_count_mobile"] ?? null) : null)) ? (("col-" . $this->sandbox->ensureToStringAllowed((($__internal_compile_5 = ($context["columns"] ?? null)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5["column_count_mobile"] ?? null) : null), 16, $this->source))) : (""))];
        // line 18
        yield "
<section ";
        // line 19
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 19, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 19, $this->source), "", $this->sandbox->ensureToStringAllowed(($context["additional_classes"] ?? null), 19, $this->source), $this->sandbox->ensureToStringAllowed(($context["component_attributes"] ?? null), 19, $this->source)));
        yield ">
  ";
        // line 20
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 20, $this->source), "html", null, true);
        yield "
  ";
        // line 21
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 21, $this->source), "html", null, true);
        yield "

  ";
        // line 23
        if (Twig\Extension\CoreExtension::spaceless(        $this->unwrap()->renderBlock("background", $context, $blocks))) {
            // line 24
            yield "    <div ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 24, $this->source)));
            yield ">
      <div ";
            // line 25
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background-media", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 25, $this->source)));
            yield ">
        ";
            // line 26
            yield from $this->unwrap()->yieldBlock('background', $context, $blocks);
            // line 28
            yield "      </div>

      <div ";
            // line 30
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background-overlay", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 30, $this->source)));
            yield ">
        ";
            // line 31
            yield from             $this->loadTemplate("@droopler_theme/base/overlay/overlay.twig", "@droopler_theme/d-p-text-paged/d-p-text-paged.twig", 31)->unwrap()->yield($context);
            // line 32
            yield "      </div>
    </div>
  ";
        }
        // line 35
        yield "
  <div ";
        // line 36
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 36, $this->source), ["container", ("text-" . $this->sandbox->ensureToStringAllowed(($context["text_align"] ?? null), 36, $this->source))]));
        yield ">
    <div ";
        // line 37
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 37, $this->source), $this->sandbox->ensureToStringAllowed(($context["content_wrapper_additiona_classes"] ?? null), 37, $this->source)));
        yield ">
      <div ";
        // line 38
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-column", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 38, $this->source), $this->sandbox->ensureToStringAllowed(($context["content_additional_classes"] ?? null), 38, $this->source)));
        yield ">
        ";
        // line 39
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 41
        yield "
        ";
        // line 42
        yield from         $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/d-p-text-paged/d-p-text-paged.twig", 42)->unwrap()->yield($context);
        // line 43
        yield "
        ";
        // line 44
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 46
        yield "
        ";
        // line 47
        yield from $this->unwrap()->yieldBlock('cta', $context, $blocks);
        // line 49
        yield "      </div>
    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["d_p_text_paged_base_class", "d_p_text_paged_modifiers", "text_align", "columns", "title_prefix", "title_suffix"]);        yield from [];
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_background(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 27
        yield "        ";
        yield from [];
    }

    // line 39
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 40
        yield "        ";
        yield from [];
    }

    // line 44
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 45
        yield "        ";
        yield from [];
    }

    // line 47
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_cta(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 48
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-text-paged/d-p-text-paged.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  209 => 48,  202 => 47,  197 => 45,  190 => 44,  185 => 40,  178 => 39,  173 => 27,  166 => 26,  156 => 49,  154 => 47,  151 => 46,  149 => 44,  146 => 43,  144 => 42,  141 => 41,  139 => 39,  135 => 38,  131 => 37,  127 => 36,  124 => 35,  119 => 32,  117 => 31,  113 => 30,  109 => 28,  107 => 26,  103 => 25,  98 => 24,  96 => 23,  91 => 21,  87 => 20,  83 => 19,  80 => 18,  78 => 16,  77 => 15,  76 => 14,  75 => 13,  72 => 12,  68 => 10,  66 => 9,  64 => 8,  61 => 7,  59 => 6,  57 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-text-paged/d-p-text-paged.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-text-paged/d-p-text-paged.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "if" => 9, "block" => 26, "include" => 31);
        static $filters = array("escape" => 1, "default" => 3, "merge" => 10, "spaceless" => 23);
        static $functions = array("attach_library" => 1, "bem" => 19);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['escape', 'default', 'merge', 'spaceless'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
