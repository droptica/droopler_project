<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-reference-content/d-p-reference-content.twig */
class __TwigTemplate_b95d88ba876692a8d08d3d389a6609da extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
            'items' => [$this, 'block_items'],
            'cta' => [$this, 'block_cta'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-reference-content"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("d_p_reference_content_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_reference_content_base_class"] ?? null), 3, $this->source), "d-p-reference-content")) : ("d-p-reference-content"));
        // line 4
        $context["modifiers"] = ((array_key_exists("d_p_reference_content_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_reference_content_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        yield "
<section ";
        // line 6
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 6, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 6, $this->source)));
        yield ">
  ";
        // line 7
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 7, $this->source), "html", null, true);
        yield "
  ";
        // line 8
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 8, $this->source), "html", null, true);
        yield "

  <div ";
        // line 10
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 10, $this->source)));
        yield ">
    <div ";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "header", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 11, $this->source), ["container"]));
        yield ">
      <div ";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "header-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 12, $this->source), ["row"]));
        yield ">
        <div ";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "header-column", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 13, $this->source), ["col-12"]));
        yield ">
          ";
        // line 14
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 16
        yield "
          ";
        // line 17
        yield from         $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/d-p-reference-content/d-p-reference-content.twig", 17)->unwrap()->yield($context);
        // line 18
        yield "
          ";
        // line 19
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 21
        yield "        </div>
      </div>
    </div>

    <div ";
        // line 25
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "items", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 25, $this->source), ["container-fluid"]));
        yield ">
      <div ";
        // line 26
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "items-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 26, $this->source), ["row"]));
        yield ">
        ";
        // line 27
        yield from $this->unwrap()->yieldBlock('items', $context, $blocks);
        // line 29
        yield "      </div>
    </div>

    <div ";
        // line 32
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "cta", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 32, $this->source), ["container"]));
        yield ">
      <div ";
        // line 33
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "cta-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 33, $this->source), ["row"]));
        yield ">
        <div ";
        // line 34
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "cta-column", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 34, $this->source), ["col-12"]));
        yield ">
          ";
        // line 35
        yield from $this->unwrap()->yieldBlock('cta', $context, $blocks);
        // line 37
        yield "        </div>
      </div>
    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["d_p_reference_content_base_class", "d_p_reference_content_modifiers", "title_prefix", "title_suffix"]);        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 15
        yield "          ";
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "          ";
        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 28
        yield "        ";
        yield from [];
    }

    // line 35
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_cta(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 36
        yield "          ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-reference-content/d-p-reference-content.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  190 => 36,  183 => 35,  178 => 28,  171 => 27,  166 => 20,  159 => 19,  154 => 15,  147 => 14,  136 => 37,  134 => 35,  130 => 34,  126 => 33,  122 => 32,  117 => 29,  115 => 27,  111 => 26,  107 => 25,  101 => 21,  99 => 19,  96 => 18,  94 => 17,  91 => 16,  89 => 14,  85 => 13,  81 => 12,  77 => 11,  73 => 10,  68 => 8,  64 => 7,  60 => 6,  57 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-reference-content/d-p-reference-content.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-reference-content/d-p-reference-content.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 14, "include" => 17);
        static $filters = array("escape" => 1, "default" => 3);
        static $functions = array("attach_library" => 1, "bem" => 6);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'include'],
                ['escape', 'default'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
