<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/block/block.twig */
class __TwigTemplate_e2166ccaffafb0e3063f5c9601b40f1e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/block"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("block_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["block_base_class"] ?? null), 3, $this->source), "block")) : ("block"));
        // line 4
        $context["modifiers"] = ((array_key_exists("block_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["block_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        $context["with_divider"] = ((array_key_exists("block_with_divider", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["block_with_divider"] ?? null), 5, $this->source), false)) : (false));
        // line 6
        yield "
<div ";
        // line 7
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 7, $this->source)));
        yield ">
  ";
        // line 8
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 8, $this->source), "html", null, true);
        yield "

  ";
        // line 10
        if (($context["label"] ?? null)) {
            // line 11
            yield "    ";
            yield from             $this->loadTemplate("@droopler_theme/base/heading/heading.twig", "@droopler_theme/block/block.twig", 11)->unwrap()->yield(CoreExtension::merge($context, ["heading_tag" => "h2", "label" =>             // line 13
($context["label"] ?? null)]));
            // line 15
            yield "
    ";
            // line 16
            if (($context["with_divider"] ?? null)) {
                // line 17
                yield "      ";
                yield from                 $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/block/block.twig", 17)->unwrap()->yield($context);
                // line 18
                yield "    ";
            }
            // line 19
            yield "
  ";
        }
        // line 21
        yield "
  ";
        // line 22
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 22, $this->source), "html", null, true);
        yield "

  <div ";
        // line 24
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 24, $this->source)));
        yield ">
    ";
        // line 25
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 27
        yield "  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["block_base_class", "block_modifiers", "block_with_divider", "title_prefix", "label", "title_suffix"]);        yield from [];
    }

    // line 25
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 26
        yield "    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/block/block.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  118 => 26,  111 => 25,  103 => 27,  101 => 25,  97 => 24,  92 => 22,  89 => 21,  85 => 19,  82 => 18,  79 => 17,  77 => 16,  74 => 15,  72 => 13,  70 => 11,  68 => 10,  63 => 8,  59 => 7,  56 => 6,  54 => 5,  52 => 4,  50 => 3,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/block/block.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/block/block.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "if" => 10, "include" => 11, "block" => 25);
        static $filters = array("escape" => 1, "default" => 3);
        static $functions = array("attach_library" => 1, "bem" => 7);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'include', 'block'],
                ['escape', 'default'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
