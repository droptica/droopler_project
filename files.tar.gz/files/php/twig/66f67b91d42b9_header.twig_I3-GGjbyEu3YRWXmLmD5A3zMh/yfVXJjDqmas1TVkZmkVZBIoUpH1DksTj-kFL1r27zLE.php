<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/header/header.twig */
class __TwigTemplate_ecdc020e27c1484b17b3389b40a5ee6a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'branding' => [$this, 'block_branding'],
            'navigation_mobile' => [$this, 'block_navigation_mobile'],
            'navigation_desktop' => [$this, 'block_navigation_desktop'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/header"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("header_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["header_base_class"] ?? null), 3, $this->source), "header")) : ("header"));
        // line 4
        yield "
<div ";
        // line 5
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 5, $this->source)));
        yield " data-theme=\"theme-light\">
  <div ";
        // line 6
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 6, $this->source), ["container"]));
        yield ">
    <div ";
        // line 7
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 7, $this->source), ["row"]));
        yield ">
      <div ";
        // line 8
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-column", ["left"], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 8, $this->source), ["col-md-3", "col-8"]));
        yield ">
        ";
        // line 9
        yield from $this->unwrap()->yieldBlock('branding', $context, $blocks);
        // line 11
        yield "      </div>
      <div ";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-column", ["right"], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 12, $this->source), ["offset-md-1", "col-md-8", "col-4"]));
        yield ">
        ";
        // line 13
        yield from         $this->loadTemplate("@droopler_theme/hamburger/hamburger.twig", "@droopler_theme/header/header.twig", 13)->unwrap()->yield($context);
        // line 14
        yield "
        ";
        // line 15
        yield from $this->unwrap()->yieldBlock('navigation_mobile', $context, $blocks);
        // line 17
        yield "
        ";
        // line 18
        yield from $this->unwrap()->yieldBlock('navigation_desktop', $context, $blocks);
        // line 20
        yield "      </div>
    </div>
  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["header_base_class"]);        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_branding(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "        ";
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navigation_mobile(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 16
        yield "        ";
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navigation_desktop(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 19
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/header/header.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  135 => 19,  128 => 18,  123 => 16,  116 => 15,  111 => 10,  104 => 9,  94 => 20,  92 => 18,  89 => 17,  87 => 15,  84 => 14,  82 => 13,  78 => 12,  75 => 11,  73 => 9,  69 => 8,  65 => 7,  61 => 6,  57 => 5,  54 => 4,  52 => 3,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/header/header.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/header/header.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 9, "include" => 13);
        static $filters = array("escape" => 1, "default" => 3);
        static $functions = array("attach_library" => 1, "bem" => 5);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'include'],
                ['escape', 'default'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
