<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/search-page-link-block/search-page-link-block.twig */
class __TwigTemplate_e364acd781c9a10e8912fca6462df790 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/search-page-link-block"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("search_page_link_block_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["search_page_link_block_base_class"] ?? null), 3, $this->source), "search-page-link-block")) : ("search-page-link-block"));
        // line 4
        yield "
<div ";
        // line 5
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 5, $this->source)));
        yield ">
  ";
        // line 6
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 8
        yield "</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["search_page_link_block_base_class"]);        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "  ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/search-page-link-block/search-page-link-block.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  75 => 7,  68 => 6,  61 => 8,  59 => 6,  55 => 5,  52 => 4,  50 => 3,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/search-page-link-block/search-page-link-block.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/search-page-link-block/search-page-link-block.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 6);
        static $filters = array("escape" => 1, "default" => 3);
        static $functions = array("attach_library" => 1, "bem" => 5);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block'],
                ['escape', 'default'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
