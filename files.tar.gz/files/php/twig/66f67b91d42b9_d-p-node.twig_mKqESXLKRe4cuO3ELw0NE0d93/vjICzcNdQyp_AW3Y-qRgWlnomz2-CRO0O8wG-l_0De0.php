<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-node/d-p-node.twig */
class __TwigTemplate_de4e165ff5178f14254462ec7ce646c8 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-node"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("d_p_node_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_node_base_class"] ?? null), 3, $this->source), "d-p-node")) : ("d-p-node"));
        // line 4
        $context["modifiers"] = ((array_key_exists("d_p_node_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_node_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        $context["additional_classes"] = Twig\Extension\CoreExtension::merge(((array_key_exists("d_p_node_additional_classes", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_node_additional_classes"] ?? null), 5, $this->source), [])) : ([])), [((CoreExtension::getAttribute($this->env, $this->source,         // line 6
($context["columns"] ?? null), "column_count_desktop", [], "any", false, false, true, 6)) ? (("col-lg-" . (12 / CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "column_count_desktop", [], "any", false, false, true, 6)))) : ("")), ((CoreExtension::getAttribute($this->env, $this->source,         // line 7
($context["columns"] ?? null), "column_count_tablet", [], "any", false, false, true, 7)) ? (("col-sm-" . (12 / CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "column_count_tablet", [], "any", false, false, true, 7)))) : ("")), ((CoreExtension::getAttribute($this->env, $this->source,         // line 8
($context["columns"] ?? null), "column_count_mobile", [], "any", false, false, true, 8)) ? (("col-xs-" . (12 / CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "column_count_mobile", [], "any", false, false, true, 8)))) : ("")), "first-child-no-spacer"]);
        // line 11
        yield "
<div ";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 12, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 12, $this->source), "", $this->sandbox->ensureToStringAllowed(($context["additional_classes"] ?? null), 12, $this->source)));
        yield ">
  ";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 13, $this->source), "html", null, true);
        yield "
  ";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 14, $this->source), "html", null, true);
        yield "

  <div ";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 16, $this->source)));
        yield ">
    ";
        // line 17
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 19
        yield "  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["d_p_node_base_class", "d_p_node_modifiers", "d_p_node_additional_classes", "columns", "title_prefix", "title_suffix"]);        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        yield "    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-node/d-p-node.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  96 => 18,  89 => 17,  81 => 19,  79 => 17,  75 => 16,  70 => 14,  66 => 13,  62 => 12,  59 => 11,  57 => 8,  56 => 7,  55 => 6,  54 => 5,  52 => 4,  50 => 3,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-node/d-p-node.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-node/d-p-node.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 17);
        static $filters = array("escape" => 1, "default" => 3, "merge" => 5);
        static $functions = array("attach_library" => 1, "bem" => 12);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block'],
                ['escape', 'default', 'merge'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
