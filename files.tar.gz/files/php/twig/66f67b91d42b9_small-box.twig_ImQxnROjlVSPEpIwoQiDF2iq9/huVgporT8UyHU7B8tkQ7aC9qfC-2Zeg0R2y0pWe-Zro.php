<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/small-box/small-box.twig */
class __TwigTemplate_a78852efac0a927555cb9ce16794047f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/small-box"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("small_box_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["small_box_base_class"] ?? null), 3, $this->source), "small-box")) : ("small-box"));
        // line 4
        $context["modifiers"] = ((array_key_exists("small_box_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["small_box_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        $context["additional_classes"] = ((array_key_exists("small_box_additional_classes", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["small_box_additional_classes"] ?? null), 5, $this->source), [])) : ([]));
        // line 6
        yield "
";
        // line 7
        $context["title"] = ((array_key_exists("small_box_title", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["small_box_title"] ?? null), 7, $this->source), "")) : (""));
        // line 8
        $context["description"] = ((array_key_exists("small_box_description", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["small_box_description"] ?? null), 8, $this->source), "")) : (""));
        // line 9
        $context["link_to_content"] = ((array_key_exists("small_box_link_to_content", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["small_box_link_to_content"] ?? null), 9, $this->source), "")) : (""));
        // line 10
        yield "
<div ";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 11, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 11, $this->source), "", $this->sandbox->ensureToStringAllowed(($context["additional_classes"] ?? null), 11, $this->source)));
        yield ">
  ";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 12, $this->source), "html", null, true);
        yield "
  ";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 13, $this->source), "html", null, true);
        yield "

  <div ";
        // line 15
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 15, $this->source)));
        yield ">
    <div ";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "image", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 16, $this->source)));
        yield ">
      ";
        // line 17
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 19
        yield "    </div>

    ";
        // line 21
        if ((($context["title"] ?? null) || ($context["description"] ?? null))) {
            // line 22
            yield "      <div ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "texts", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 22, $this->source)));
            yield ">
        <div ";
            // line 23
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "title", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 23, $this->source)));
            yield ">
          <a ";
            // line 24
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "link", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 24, $this->source)));
            yield " href=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["link_to_content"] ?? null), 24, $this->source), "html", null, true);
            yield "\">
            <h2 ";
            // line 25
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "heading", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 25, $this->source)));
            yield ">
              ";
            // line 26
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title"] ?? null), 26, $this->source), "html", null, true);
            yield "
            </h2>
          </a>
        </div>

        <div ";
            // line 31
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "description", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 31, $this->source)));
            yield ">
          <a ";
            // line 32
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "link", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 32, $this->source)));
            yield " href=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["link_to_content"] ?? null), 32, $this->source), "html", null, true);
            yield "\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["description"] ?? null), 32, $this->source), "html", null, true);
            yield "</a>
        </div>
      </div>
    ";
        }
        // line 36
        yield "  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["small_box_base_class", "small_box_modifiers", "small_box_additional_classes", "small_box_title", "small_box_description", "small_box_link_to_content", "title_prefix", "title_suffix"]);        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        yield "      ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/small-box/small-box.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  154 => 18,  147 => 17,  139 => 36,  128 => 32,  124 => 31,  116 => 26,  112 => 25,  106 => 24,  102 => 23,  97 => 22,  95 => 21,  91 => 19,  89 => 17,  85 => 16,  81 => 15,  76 => 13,  72 => 12,  68 => 11,  65 => 10,  63 => 9,  61 => 8,  59 => 7,  56 => 6,  54 => 5,  52 => 4,  50 => 3,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/small-box/small-box.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/small-box/small-box.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 17, "if" => 21);
        static $filters = array("escape" => 1, "default" => 3);
        static $functions = array("attach_library" => 1, "bem" => 11);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if'],
                ['escape', 'default'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
