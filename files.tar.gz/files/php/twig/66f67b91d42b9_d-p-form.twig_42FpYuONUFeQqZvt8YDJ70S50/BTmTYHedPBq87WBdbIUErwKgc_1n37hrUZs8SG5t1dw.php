<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-form/d-p-form.twig */
class __TwigTemplate_a8777ff1829e7e7183e8aceb75e226b5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'background' => [$this, 'block_background'],
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
            'form' => [$this, 'block_form'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-form"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("d_p_banner_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_banner_base_class"] ?? null), 3, $this->source), "d-p-form")) : ("d-p-form"));
        // line 4
        $context["modifiers"] = ((array_key_exists("d_p_form_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_form_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        if (($context["form_placement"] ?? null)) {
            // line 6
            yield "  ";
            $context["modifiers"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 6, $this->source), [($context["form_placement"] ?? null)]);
        }
        // line 8
        yield "
";
        // line 9
        if ((($context["form_placement"] ?? null) == "left")) {
            // line 10
            yield "  ";
            $context["content_classes"] = "col-md-5 col-12";
            // line 11
            yield "  ";
            $context["form_classes"] = "col-md-7 col-12";
        } elseif ((        // line 12
($context["form_placement"] ?? null) == "right")) {
            // line 13
            yield "  ";
            $context["content_classes"] = "col-md-5 col-12";
            // line 14
            yield "  ";
            $context["form_classes"] = "col-md-7 col-12";
        } else {
            // line 16
            yield "  ";
            $context["content_classes"] = "col-md-8";
            // line 17
            yield "  ";
            $context["form_classes"] = "col-md-8";
        }
        // line 19
        yield "
<section ";
        // line 20
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 20, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 20, $this->source)));
        yield ">
  ";
        // line 21
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 21, $this->source), "html", null, true);
        yield "
  ";
        // line 22
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 22, $this->source), "html", null, true);
        yield "

  <div ";
        // line 24
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 24, $this->source)));
        yield ">
    <div ";
        // line 25
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background-media", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 25, $this->source)));
        yield ">
      ";
        // line 26
        yield from $this->unwrap()->yieldBlock('background', $context, $blocks);
        // line 28
        yield "    </div>

    <div ";
        // line 30
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background-overlay", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 30, $this->source)));
        yield ">
      ";
        // line 31
        yield from         $this->loadTemplate("@droopler_theme/base/overlay/overlay.twig", "@droopler_theme/d-p-form/d-p-form.twig", 31)->unwrap()->yield($context);
        // line 32
        yield "    </div>
  </div>

    <div ";
        // line 35
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 35, $this->source), ["container"]));
        yield ">
      <div ";
        // line 36
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 36, $this->source), ["row"]));
        yield ">

        ";
        // line 38
        $context["has_header"] =  !Twig\Extension\CoreExtension::testEmpty(Twig\Extension\CoreExtension::trim(Twig\Extension\CoreExtension::striptags($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(        $this->unwrap()->renderBlock("header", $context, $blocks)), "<img>")));
        // line 39
        yield "        ";
        $context["has_content"] =  !Twig\Extension\CoreExtension::testEmpty(Twig\Extension\CoreExtension::trim(Twig\Extension\CoreExtension::striptags($this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(        $this->unwrap()->renderBlock("content", $context, $blocks)))));
        // line 40
        yield "
        ";
        // line 41
        if ((($context["has_header"] ?? null) || ($context["has_content"] ?? null))) {
            // line 42
            yield "          <div ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-column", ["header"], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 42, $this->source), [($context["content_classes"] ?? null), "first-child-no-spacer"]));
            yield ">
            ";
            // line 43
            if (($context["has_header"] ?? null)) {
                // line 44
                yield "              ";
                yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
                // line 46
                yield "
              ";
                // line 47
                if (($context["has_content"] ?? null)) {
                    // line 48
                    yield "                ";
                    yield from                     $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/d-p-form/d-p-form.twig", 48)->unwrap()->yield($context);
                    // line 49
                    yield "              ";
                }
                // line 50
                yield "            ";
            }
            // line 51
            yield "
            ";
            // line 52
            yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
            // line 54
            yield "          </div>
        ";
        }
        // line 56
        yield "
        <div ";
        // line 57
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-column", ["form"], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 57, $this->source), [($context["form_classes"] ?? null)]));
        yield ">
          ";
        // line 58
        yield from $this->unwrap()->yieldBlock('form', $context, $blocks);
        // line 60
        yield "        </div>
      </div>
    </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["d_p_banner_base_class", "d_p_form_modifiers", "form_placement", "title_prefix", "title_suffix"]);        yield from [];
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_background(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 27
        yield "      ";
        yield from [];
    }

    // line 44
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 45
        yield "              ";
        yield from [];
    }

    // line 52
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 53
        yield "            ";
        yield from [];
    }

    // line 58
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 59
        yield "          ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-form/d-p-form.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  245 => 59,  238 => 58,  233 => 53,  226 => 52,  221 => 45,  214 => 44,  209 => 27,  202 => 26,  192 => 60,  190 => 58,  186 => 57,  183 => 56,  179 => 54,  177 => 52,  174 => 51,  171 => 50,  168 => 49,  165 => 48,  163 => 47,  160 => 46,  157 => 44,  155 => 43,  150 => 42,  148 => 41,  145 => 40,  142 => 39,  140 => 38,  135 => 36,  131 => 35,  126 => 32,  124 => 31,  120 => 30,  116 => 28,  114 => 26,  110 => 25,  106 => 24,  101 => 22,  97 => 21,  93 => 20,  90 => 19,  86 => 17,  83 => 16,  79 => 14,  76 => 13,  74 => 12,  71 => 11,  68 => 10,  66 => 9,  63 => 8,  59 => 6,  57 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-form/d-p-form.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-form/d-p-form.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "if" => 5, "block" => 26, "include" => 31);
        static $filters = array("escape" => 1, "default" => 3, "merge" => 6, "trim" => 38, "striptags" => 38, "render" => 38);
        static $functions = array("attach_library" => 1, "bem" => 20);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['escape', 'default', 'merge', 'trim', 'striptags', 'render'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
