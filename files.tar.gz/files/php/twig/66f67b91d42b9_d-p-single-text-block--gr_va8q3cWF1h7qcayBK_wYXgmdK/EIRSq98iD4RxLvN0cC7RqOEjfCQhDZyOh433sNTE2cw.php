<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-single-text-block/d-p-single-text-block--group.twig */
class __TwigTemplate_6d8bea597b0ef5aee018a9caa8e0d1b9 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'background' => [$this, 'block_background'],
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-single-text-block"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("d_p_single_text_blocks_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_single_text_blocks_base_class"] ?? null), 3, $this->source), "d-p-single-text-block")) : ("d-p-single-text-block"));
        // line 4
        $context["modifiers"] = Twig\Extension\CoreExtension::merge(((array_key_exists("d_p_single_text_blocks_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_single_text_blocks_modifiers"] ?? null), 4, $this->source), [])) : ([])), [((        // line 5
($context["has_background"] ?? null)) ? ("has-media-background") : (""))]);
        // line 7
        $context["additional_classes"] = Twig\Extension\CoreExtension::merge(((array_key_exists("d_p_single_text_block_additional_classes", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_single_text_block_additional_classes"] ?? null), 7, $this->source), [])) : ([])), ["col"]);
        // line 8
        yield "
";
        // line 9
        if (($context["is_tile"] ?? null)) {
            // line 10
            yield "  ";
            $context["modifiers"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 10, $this->source), ["tile"]);
        }
        // line 12
        yield "
";
        // line 13
        if (($context["is_grid"] ?? null)) {
            // line 14
            yield "  ";
            $context["modifiers"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 14, $this->source), ["grid-column"]);
        }
        // line 16
        yield "
<div ";
        // line 17
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 17, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 17, $this->source), "", $this->sandbox->ensureToStringAllowed(($context["additional_classes"] ?? null), 17, $this->source)));
        yield ">
  <div ";
        // line 18
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 18, $this->source)));
        yield ">
    <div ";
        // line 19
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 19, $this->source)));
        yield ">
      <div ";
        // line 20
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background-media", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 20, $this->source)));
        yield ">
        ";
        // line 21
        yield from $this->unwrap()->yieldBlock('background', $context, $blocks);
        // line 23
        yield "      </div>
    </div>

    <div ";
        // line 26
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 26, $this->source)));
        yield ">
      ";
        // line 27
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 29
        yield "
      ";
        // line 30
        yield from         $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/d-p-single-text-block/d-p-single-text-block--group.twig", 30)->unwrap()->yield($context);
        // line 31
        yield "
      ";
        // line 32
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 34
        yield "
      ";
        // line 35
        if (($context["with_price"] ?? null)) {
            // line 36
            yield "        ";
            yield from             $this->loadTemplate("@droopler_theme/price-block/price-block.twig", "@droopler_theme/d-p-single-text-block/d-p-single-text-block--group.twig", 36)->unwrap()->yield(CoreExtension::merge($context, ["sidebar" =>             // line 37
($context["with_price_in_sidebar"] ?? null)]));
            // line 39
            yield "      ";
        }
        // line 40
        yield "    </div>
  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["d_p_single_text_blocks_base_class", "d_p_single_text_blocks_modifiers", "has_background", "d_p_single_text_block_additional_classes", "is_tile", "is_grid", "with_price", "with_price_in_sidebar"]);        yield from [];
    }

    // line 21
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_background(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 22
        yield "        ";
        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 28
        yield "      ";
        yield from [];
    }

    // line 32
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 33
        yield "      ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-single-text-block/d-p-single-text-block--group.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  171 => 33,  164 => 32,  159 => 28,  152 => 27,  147 => 22,  140 => 21,  131 => 40,  128 => 39,  126 => 37,  124 => 36,  122 => 35,  119 => 34,  117 => 32,  114 => 31,  112 => 30,  109 => 29,  107 => 27,  103 => 26,  98 => 23,  96 => 21,  92 => 20,  88 => 19,  84 => 18,  80 => 17,  77 => 16,  73 => 14,  71 => 13,  68 => 12,  64 => 10,  62 => 9,  59 => 8,  57 => 7,  55 => 5,  54 => 4,  52 => 3,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-single-text-block/d-p-single-text-block--group.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-single-text-block/d-p-single-text-block--group.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "if" => 9, "block" => 21, "include" => 30);
        static $filters = array("escape" => 1, "default" => 3, "merge" => 4);
        static $functions = array("attach_library" => 1, "bem" => 17);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['escape', 'default', 'merge'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
