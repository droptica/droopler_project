<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/menu-item/menu-item.twig */
class __TwigTemplate_3f158cb2ac1b503cc168b1f0a5e71150 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/menu-item"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("menu_item_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["menu_item_base_class"] ?? null), 3, $this->source), "menu-item")) : ("menu-item"));
        // line 4
        $context["modifiers"] = ((array_key_exists("menu_item_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["menu_item_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        $context["depth"] = ((array_key_exists("depth", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["depth"] ?? null), 5, $this->source),  -1)) : ( -1));
        // line 6
        yield "
";
        // line 7
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "in_active_trail", [], "any", false, false, true, 7)) {
            // line 8
            yield "  ";
            $context["modifiers"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 8, $this->source), ["active"]);
        }
        // line 10
        yield "
";
        // line 11
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 11)) {
            // line 12
            yield "  ";
            $context["modifiers"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 12, $this->source), ["has-submenu"]);
        }
        // line 14
        yield "
<li ";
        // line 15
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 15, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 15, $this->source)));
        yield " ";
        if ((($context["depth"] ?? null) >= 0)) {
            yield "style=\"--navigation-mobile-level: ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["depth"] ?? null), 15, $this->source), "html", null, true);
            yield "\"";
        }
        yield ">
  <span ";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "element", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 16, $this->source)));
        yield ">
    <a ";
        // line 17
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "link", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 17, $this->source)));
        yield " href=\"";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "url", [], "any", false, false, true, 17), 17, $this->source), "html", null, true);
        yield "\">
      ";
        // line 18
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "title", [], "any", false, false, true, 18), 18, $this->source), "html", null, true);
        yield "
    </a>
    ";
        // line 20
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 20)) {
            // line 21
            yield "      <a ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "toggler", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 21, $this->source)));
            yield " href=\"#\">
        ";
            // line 22
            yield from             $this->loadTemplate("@droopler_theme/base/icon/icon.twig", "@droopler_theme/menu-item/menu-item.twig", 22)->unwrap()->yield(CoreExtension::merge($context, ["icon_modifiers" => ["open"], "icon_name" => "down-open-big"]));
            // line 26
            yield "        ";
            yield from             $this->loadTemplate("@droopler_theme/base/icon/icon.twig", "@droopler_theme/menu-item/menu-item.twig", 26)->unwrap()->yield(CoreExtension::merge($context, ["icon_modifiers" => ["close"], "icon_name" => "up-open-big"]));
            // line 30
            yield "      </a>
    ";
        }
        // line 32
        yield "  </span>
  ";
        // line 33
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "below", [], "any", false, false, true, 33)) {
            // line 34
            yield "    ";
            yield from             $this->loadTemplate("@droopler_theme/menu/menu.twig", "@droopler_theme/menu-item/menu-item.twig", 34)->unwrap()->yield(CoreExtension::merge($context, ["menu_base_class" => "submenu", "menu_item_base_class" => "submenu-item", "items" => CoreExtension::getAttribute($this->env, $this->source,             // line 37
($context["item"] ?? null), "below", [], "any", false, false, true, 37), "depth" => (            // line 38
($context["depth"] ?? null) + 1)]));
            // line 40
            yield "  ";
        }
        // line 41
        yield "</li>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["menu_item_base_class", "menu_item_modifiers", "item"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/menu-item/menu-item.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  130 => 41,  127 => 40,  125 => 38,  124 => 37,  122 => 34,  120 => 33,  117 => 32,  113 => 30,  110 => 26,  108 => 22,  103 => 21,  101 => 20,  96 => 18,  90 => 17,  86 => 16,  76 => 15,  73 => 14,  69 => 12,  67 => 11,  64 => 10,  60 => 8,  58 => 7,  55 => 6,  53 => 5,  51 => 4,  49 => 3,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/menu-item/menu-item.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/menu-item/menu-item.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "if" => 7, "include" => 22);
        static $filters = array("escape" => 1, "default" => 3, "merge" => 8);
        static $functions = array("attach_library" => 1, "bem" => 15);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'include'],
                ['escape', 'default', 'merge'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
