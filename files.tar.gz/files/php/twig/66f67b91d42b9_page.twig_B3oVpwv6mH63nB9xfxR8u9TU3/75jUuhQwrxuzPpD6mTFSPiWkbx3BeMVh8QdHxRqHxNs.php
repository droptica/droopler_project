<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/page/page.twig */
class __TwigTemplate_ef985202fa2ee5b946c89a1d1eb5d05e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'admin_tabs' => [$this, 'block_admin_tabs'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/page"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("page_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["page_base_class"] ?? null), 3, $this->source), "page")) : ("page"));
        // line 4
        yield "
<div ";
        // line 5
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 5, $this->source)));
        yield ">
  <main ";
        // line 6
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "main", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 6, $this->source)));
        yield ">
    ";
        // line 7
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 37
        yield "
    ";
        // line 38
        yield from $this->unwrap()->yieldBlock('admin_tabs', $context, $blocks);
        // line 45
        yield "
    ";
        // line 46
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 58
        yield "  </main>

  ";
        // line 60
        yield from $this->unwrap()->yieldBlock('footer', $context, $blocks);
        // line 82
        yield "</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["page_base_class", "page"]);        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "    <header ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "header", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 8, $this->source)));
        yield ">
      ";
        // line 9
        yield from         $this->loadTemplate("@droopler_theme/page/page.twig", "@droopler_theme/page/page.twig", 9, "2129511088")->unwrap()->yield($context);
        // line 35
        yield "    </header>
    ";
        yield from [];
    }

    // line 38
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_admin_tabs(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 39
        yield "    ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "admin_tabs", [], "any", false, false, true, 39)) {
            // line 40
            yield "      <div ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "admin-tabs", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 40, $this->source), ["container"]));
            yield ">
        ";
            // line 41
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "admin_tabs", [], "any", false, false, true, 41), 41, $this->source), "html", null, true);
            yield "
      </div>
    ";
        }
        // line 44
        yield "    ";
        yield from [];
    }

    // line 46
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 47
        yield "      <div ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 47, $this->source), ["container"]));
        yield ">
        <div ";
        // line 48
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 48, $this->source)));
        yield ">
          ";
        // line 49
        yield from         $this->loadTemplate("@droopler_theme/base/heading/heading.twig", "@droopler_theme/page/page.twig", 49)->unwrap()->yield(CoreExtension::merge($context, ["heading_tag" => "h1", "label" => (($__internal_compile_0 =         // line 51
($context["page"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["#title"] ?? null) : null)]));
        // line 53
        yield "
          ";
        // line 54
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 54), 54, $this->source), "html", null, true);
        yield "
        </div>
      </div>
    ";
        yield from [];
    }

    // line 60
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 61
        yield "  <footer ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "footer", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 61, $this->source)));
        yield ">
    ";
        // line 62
        yield from         $this->loadTemplate("@droopler_theme/page/page.twig", "@droopler_theme/page/page.twig", 62, "462002245")->unwrap()->yield($context);
        // line 74
        yield "
    ";
        // line 75
        yield from         $this->loadTemplate("@droopler_theme/page/page.twig", "@droopler_theme/page/page.twig", 75, "16914205")->unwrap()->yield($context);
        // line 80
        yield "  </footer>
  ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/page/page.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  187 => 80,  185 => 75,  182 => 74,  180 => 62,  175 => 61,  168 => 60,  159 => 54,  156 => 53,  154 => 51,  153 => 49,  149 => 48,  144 => 47,  137 => 46,  132 => 44,  126 => 41,  121 => 40,  118 => 39,  111 => 38,  105 => 35,  103 => 9,  98 => 8,  91 => 7,  84 => 82,  82 => 60,  78 => 58,  76 => 46,  73 => 45,  71 => 38,  68 => 37,  66 => 7,  62 => 6,  58 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/page/page.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/page/page.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "block" => 7, "embed" => 9, "if" => 39, "include" => 49);
        static $filters = array("escape" => 1, "default" => 3);
        static $functions = array("attach_library" => 1, "bem" => 5);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'embed', 'if', 'include'],
                ['escape', 'default'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* @droopler_theme/page/page.twig */
class __TwigTemplate_ef985202fa2ee5b946c89a1d1eb5d05e___2129511088 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'branding' => [$this, 'block_branding'],
            'navigation_desktop' => [$this, 'block_navigation_desktop'],
            'navigation_mobile' => [$this, 'block_navigation_mobile'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 9
        return "@droopler_theme/header/header.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/header/header.twig", "@droopler_theme/page/page.twig", 9);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["page"]);    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_branding(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        yield "          ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_branding", [], "any", false, false, true, 11), 11, $this->source), "html", null, true);
        yield "
        ";
        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navigation_desktop(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 15
        yield "          ";
        yield from         $this->loadTemplate("@droopler_theme/page/page.twig", "@droopler_theme/page/page.twig", 15, "1192518220")->unwrap()->yield($context);
        // line 24
        yield "        ";
        yield from [];
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navigation_mobile(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 27
        yield "          ";
        yield from         $this->loadTemplate("@droopler_theme/page/page.twig", "@droopler_theme/page/page.twig", 27, "418270933")->unwrap()->yield($context);
        // line 33
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/page/page.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  331 => 33,  328 => 27,  321 => 26,  316 => 24,  313 => 15,  306 => 14,  298 => 11,  291 => 10,  279 => 9,  187 => 80,  185 => 75,  182 => 74,  180 => 62,  175 => 61,  168 => 60,  159 => 54,  156 => 53,  154 => 51,  153 => 49,  149 => 48,  144 => 47,  137 => 46,  132 => 44,  126 => 41,  121 => 40,  118 => 39,  111 => 38,  105 => 35,  103 => 9,  98 => 8,  91 => 7,  84 => 82,  82 => 60,  78 => 58,  76 => 46,  73 => 45,  71 => 38,  68 => 37,  66 => 7,  62 => 6,  58 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/page/page.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/page/page.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 9, "embed" => 15);
        static $filters = array("escape" => 11);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends', 'embed'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* @droopler_theme/page/page.twig */
class __TwigTemplate_ef985202fa2ee5b946c89a1d1eb5d05e___1192518220 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'top_content' => [$this, 'block_top_content'],
            'bottom_content' => [$this, 'block_bottom_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 15
        return "@droopler_theme/navigation-desktop/navigation-desktop.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/navigation-desktop/navigation-desktop.twig", "@droopler_theme/page/page.twig", 15);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["page"]);    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_top_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "              ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_secondary", [], "any", false, false, true, 17), 17, $this->source), "html", null, true);
        yield "
            ";
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_bottom_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 21
        yield "              ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_primary", [], "any", false, false, true, 21), 21, $this->source), "html", null, true);
        yield "
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/page/page.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  455 => 21,  448 => 20,  440 => 17,  433 => 16,  421 => 15,  331 => 33,  328 => 27,  321 => 26,  316 => 24,  313 => 15,  306 => 14,  298 => 11,  291 => 10,  279 => 9,  187 => 80,  185 => 75,  182 => 74,  180 => 62,  175 => 61,  168 => 60,  159 => 54,  156 => 53,  154 => 51,  153 => 49,  149 => 48,  144 => 47,  137 => 46,  132 => 44,  126 => 41,  121 => 40,  118 => 39,  111 => 38,  105 => 35,  103 => 9,  98 => 8,  91 => 7,  84 => 82,  82 => 60,  78 => 58,  76 => 46,  73 => 45,  71 => 38,  68 => 37,  66 => 7,  62 => 6,  58 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/page/page.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/page/page.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 15);
        static $filters = array("escape" => 17);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* @droopler_theme/page/page.twig */
class __TwigTemplate_ef985202fa2ee5b946c89a1d1eb5d05e___418270933 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 27
        return "@droopler_theme/navigation-mobile/navigation-mobile.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/navigation-mobile/navigation-mobile.twig", "@droopler_theme/page/page.twig", 27);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["page"]);    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 29
        yield "              ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_primary", [], "any", false, false, true, 29), 29, $this->source), "html", null, true);
        yield "
              ";
        // line 30
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header_secondary", [], "any", false, false, true, 30), 30, $this->source), "html", null, true);
        yield "
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/page/page.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  571 => 30,  566 => 29,  559 => 28,  547 => 27,  455 => 21,  448 => 20,  440 => 17,  433 => 16,  421 => 15,  331 => 33,  328 => 27,  321 => 26,  316 => 24,  313 => 15,  306 => 14,  298 => 11,  291 => 10,  279 => 9,  187 => 80,  185 => 75,  182 => 74,  180 => 62,  175 => 61,  168 => 60,  159 => 54,  156 => 53,  154 => 51,  153 => 49,  149 => 48,  144 => 47,  137 => 46,  132 => 44,  126 => 41,  121 => 40,  118 => 39,  111 => 38,  105 => 35,  103 => 9,  98 => 8,  91 => 7,  84 => 82,  82 => 60,  78 => 58,  76 => 46,  73 => 45,  71 => 38,  68 => 37,  66 => 7,  62 => 6,  58 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/page/page.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/page/page.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 27);
        static $filters = array("escape" => 29);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* @droopler_theme/page/page.twig */
class __TwigTemplate_ef985202fa2ee5b946c89a1d1eb5d05e___462002245 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'columns' => [$this, 'block_columns'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 62
        return "@droopler_theme/footer-primary/footer-primary.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/footer-primary/footer-primary.twig", "@droopler_theme/page/page.twig", 62);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["footer_primary_regions", "footer_primary_regions_count"]);    }

    // line 63
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_columns(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 64
        yield "        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footer_primary_regions"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["region"]) {
            // line 65
            yield "          ";
            yield from             $this->loadTemplate("@droopler_theme/page/page.twig", "@droopler_theme/page/page.twig", 65, "1567286964")->unwrap()->yield(CoreExtension::merge($context, ["column_count" => Twig\Extension\CoreExtension::round((12 /             // line 66
($context["footer_primary_regions_count"] ?? null)), 0, "floor")]));
            // line 71
            yield "        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['region'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 72
        yield "      ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/page/page.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  717 => 72,  703 => 71,  701 => 66,  699 => 65,  681 => 64,  674 => 63,  662 => 62,  571 => 30,  566 => 29,  559 => 28,  547 => 27,  455 => 21,  448 => 20,  440 => 17,  433 => 16,  421 => 15,  331 => 33,  328 => 27,  321 => 26,  316 => 24,  313 => 15,  306 => 14,  298 => 11,  291 => 10,  279 => 9,  187 => 80,  185 => 75,  182 => 74,  180 => 62,  175 => 61,  168 => 60,  159 => 54,  156 => 53,  154 => 51,  153 => 49,  149 => 48,  144 => 47,  137 => 46,  132 => 44,  126 => 41,  121 => 40,  118 => 39,  111 => 38,  105 => 35,  103 => 9,  98 => 8,  91 => 7,  84 => 82,  82 => 60,  78 => 58,  76 => 46,  73 => 45,  71 => 38,  68 => 37,  66 => 7,  62 => 6,  58 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/page/page.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/page/page.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 62, "for" => 64, "embed" => 65);
        static $filters = array("round" => 66);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends', 'for', 'embed'],
                ['round'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* @droopler_theme/page/page.twig */
class __TwigTemplate_ef985202fa2ee5b946c89a1d1eb5d05e___1567286964 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 65
        return "@droopler_theme/footer-primary-column/footer-primary-column.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/footer-primary-column/footer-primary-column.twig", "@droopler_theme/page/page.twig", 65);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["region"]);    }

    // line 67
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 68
        yield "              ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["region"] ?? null), 68, $this->source), "html", null, true);
        yield "
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/page/page.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  825 => 68,  818 => 67,  806 => 65,  717 => 72,  703 => 71,  701 => 66,  699 => 65,  681 => 64,  674 => 63,  662 => 62,  571 => 30,  566 => 29,  559 => 28,  547 => 27,  455 => 21,  448 => 20,  440 => 17,  433 => 16,  421 => 15,  331 => 33,  328 => 27,  321 => 26,  316 => 24,  313 => 15,  306 => 14,  298 => 11,  291 => 10,  279 => 9,  187 => 80,  185 => 75,  182 => 74,  180 => 62,  175 => 61,  168 => 60,  159 => 54,  156 => 53,  154 => 51,  153 => 49,  149 => 48,  144 => 47,  137 => 46,  132 => 44,  126 => 41,  121 => 40,  118 => 39,  111 => 38,  105 => 35,  103 => 9,  98 => 8,  91 => 7,  84 => 82,  82 => 60,  78 => 58,  76 => 46,  73 => 45,  71 => 38,  68 => 37,  66 => 7,  62 => 6,  58 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/page/page.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/page/page.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 65);
        static $filters = array("escape" => 68);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}


/* @droopler_theme/page/page.twig */
class __TwigTemplate_ef985202fa2ee5b946c89a1d1eb5d05e___16914205 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 75
        return "@droopler_theme/footer-secondary/footer-secondary.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@droopler_theme/footer-secondary/footer-secondary.twig", "@droopler_theme/page/page.twig", 75);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["page"]);    }

    // line 76
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 77
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_secondary", [], "any", false, false, true, 77), 77, $this->source), "html", null, true);
        yield "
      ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/page/page.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  936 => 77,  929 => 76,  917 => 75,  825 => 68,  818 => 67,  806 => 65,  717 => 72,  703 => 71,  701 => 66,  699 => 65,  681 => 64,  674 => 63,  662 => 62,  571 => 30,  566 => 29,  559 => 28,  547 => 27,  455 => 21,  448 => 20,  440 => 17,  433 => 16,  421 => 15,  331 => 33,  328 => 27,  321 => 26,  316 => 24,  313 => 15,  306 => 14,  298 => 11,  291 => 10,  279 => 9,  187 => 80,  185 => 75,  182 => 74,  180 => 62,  175 => 61,  168 => 60,  159 => 54,  156 => 53,  154 => 51,  153 => 49,  149 => 48,  144 => 47,  137 => 46,  132 => 44,  126 => 41,  121 => 40,  118 => 39,  111 => 38,  105 => 35,  103 => 9,  98 => 8,  91 => 7,  84 => 82,  82 => 60,  78 => 58,  76 => 46,  73 => 45,  71 => 38,  68 => 37,  66 => 7,  62 => 6,  58 => 5,  55 => 4,  53 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/page/page.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/page/page.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("extends" => 75);
        static $filters = array("escape" => 77);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['extends'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
