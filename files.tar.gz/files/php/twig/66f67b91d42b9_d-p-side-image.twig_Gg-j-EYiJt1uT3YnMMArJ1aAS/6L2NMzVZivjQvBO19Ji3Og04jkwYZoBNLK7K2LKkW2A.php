<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/d-p-side-image/d-p-side-image.twig */
class __TwigTemplate_59febca3ea1f334b2c7f034a489982ca extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'background' => [$this, 'block_background'],
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/d-p-side-image"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("d_p_side_image_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_side_image_base_class"] ?? null), 3, $this->source), "d-p-side-image")) : ("d-p-side-image"));
        // line 4
        $context["modifiers"] = ((array_key_exists("d_p_side_image_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["d_p_side_image_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        $context["image_side"] = ((array_key_exists("image_side", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["image_side"] ?? null), 5, $this->source), false)) : (false));
        // line 6
        yield "
";
        // line 7
        if ((($context["image_width"] ?? null) == "wide")) {
            // line 8
            yield "  ";
            $context["wide_image"] = "col-md-6 col-lg-7";
            // line 9
            yield "  ";
            $context["content_column_count"] = (((($context["image_side"] ?? null) == "right")) ? ("5") : ("5 offset-md-7"));
            // line 10
            yield "  ";
            $context["content_column_count_lg"] = (((($context["image_side"] ?? null) == "right")) ? ("4") : ("4 offset-lg-8"));
            // line 11
            yield "  ";
            $context["content_column_count_wide"] = (((($context["image_side"] ?? null) == "right")) ? ("4") : ("4 offset-xl-8"));
        } else {
            // line 13
            yield "  ";
            $context["content_column_count"] = (((($context["image_side"] ?? null) == "right")) ? ("5") : ("5 offset-md-7"));
        }
        // line 15
        yield "
";
        // line 16
        $context["content_classes"] = [("col-md-" . $this->sandbox->ensureToStringAllowed(        // line 17
($context["content_column_count"] ?? null), 17, $this->source)), ("col-lg-" . $this->sandbox->ensureToStringAllowed(        // line 18
($context["content_column_count_lg"] ?? null), 18, $this->source)), ((        // line 19
($context["content_column_count_wide"] ?? null)) ? (("col-xl-" . $this->sandbox->ensureToStringAllowed(($context["content_column_count_wide"] ?? null), 19, $this->source))) : ("")), "col-12"];
        // line 22
        yield "
<section ";
        // line 23
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 23, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 23, $this->source)));
        yield ">
  ";
        // line 24
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null), 24, $this->source), "html", null, true);
        yield "
  ";
        // line 25
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null), 25, $this->source), "html", null, true);
        yield "
  <div ";
        // line 26
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "background", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 26, $this->source), [(($context["wide_image"]) ?? ("col-md-6")), ($context["image_side"] ?? null)]));
        yield ">
    ";
        // line 27
        yield from $this->unwrap()->yieldBlock('background', $context, $blocks);
        // line 29
        yield "  </div>
  <div ";
        // line 30
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 30, $this->source), ["container", ($context["image_side"] ?? null)]));
        yield ">
    <div ";
        // line 31
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-wrapper", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 31, $this->source), ["row"]));
        yield ">
      <div ";
        // line 32
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "content-column", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 32, $this->source), $this->sandbox->ensureToStringAllowed(($context["content_classes"] ?? null), 32, $this->source)));
        yield ">
        ";
        // line 33
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 35
        yield "
        ";
        // line 36
        yield from         $this->loadTemplate("@droopler_theme/base/divider/divider.twig", "@droopler_theme/d-p-side-image/d-p-side-image.twig", 36)->unwrap()->yield($context);
        // line 37
        yield "
        ";
        // line 38
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 40
        yield "      </div>
    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["d_p_side_image_base_class", "d_p_side_image_modifiers", "image_width", "title_prefix", "title_suffix"]);        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_background(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 28
        yield "    ";
        yield from [];
    }

    // line 33
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 34
        yield "        ";
        yield from [];
    }

    // line 38
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 39
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/d-p-side-image/d-p-side-image.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  177 => 39,  170 => 38,  165 => 34,  158 => 33,  153 => 28,  146 => 27,  136 => 40,  134 => 38,  131 => 37,  129 => 36,  126 => 35,  124 => 33,  120 => 32,  116 => 31,  112 => 30,  109 => 29,  107 => 27,  103 => 26,  99 => 25,  95 => 24,  91 => 23,  88 => 22,  86 => 19,  85 => 18,  84 => 17,  83 => 16,  80 => 15,  76 => 13,  72 => 11,  69 => 10,  66 => 9,  63 => 8,  61 => 7,  58 => 6,  56 => 5,  54 => 4,  52 => 3,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/d-p-side-image/d-p-side-image.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/d-p-side-image/d-p-side-image.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "if" => 7, "block" => 27, "include" => 36);
        static $filters = array("escape" => 1, "default" => 3);
        static $functions = array("attach_library" => 1, "bem" => 23);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['escape', 'default'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
