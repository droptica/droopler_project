<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @droopler_theme/price-block/price-block.twig */
class __TwigTemplate_cbb92bc7a2d14a14131c67da56c26a8c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("droopler_theme/price-block"), "html", null, true);
        yield "

";
        // line 3
        $context["base_class"] = ((array_key_exists("price_block_base_class", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["price_block_base_class"] ?? null), 3, $this->source), "price-block")) : ("price-block"));
        // line 4
        $context["modifiers"] = ((array_key_exists("price_block_modifiers", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["price_block_modifiers"] ?? null), 4, $this->source), [])) : ([]));
        // line 5
        $context["additional_classes"] = ((array_key_exists("price_block_additional_classes", $context)) ? (Twig\Extension\CoreExtension::default($this->sandbox->ensureToStringAllowed(($context["price_block_additional_classes"] ?? null), 5, $this->source), [])) : ([]));
        // line 6
        yield "
";
        // line 7
        if (($context["sidebar"] ?? null)) {
            // line 8
            yield "  ";
            $context["modifiers"] = Twig\Extension\CoreExtension::merge($this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 8, $this->source), ["sidebar"]);
        }
        // line 10
        yield "
<div ";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 11, $this->source), $this->sandbox->ensureToStringAllowed(($context["modifiers"] ?? null), 11, $this->source), "", $this->sandbox->ensureToStringAllowed(($context["additional_classes"] ?? null), 11, $this->source)));
        yield ">
  <div ";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "spinner", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 12, $this->source), ["spinner-border"]));
        yield " role=\"status\">
    <span class=\"sr-only\"></span>
  </div>
  <div ";
        // line 15
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "data", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 15, $this->source)));
        yield ">
    <span ";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "value", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 16, $this->source)));
        yield "></span>
    <span ";
        // line 17
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "currency", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 17, $this->source)));
        yield "></span>
  </div>
  <div ";
        // line 19
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "change", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 19, $this->source)));
        yield ">
    <div ";
        // line 20
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "arrow", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 20, $this->source)));
        yield "></div>
    <div ";
        // line 21
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "percentage", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 21, $this->source)));
        yield "></div>
  </div>
  <div ";
        // line 23
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\d_twig_extensions\BemFunction']->bemTwigFunction($context, "timestamp", [], $this->sandbox->ensureToStringAllowed(($context["base_class"] ?? null), 23, $this->source)));
        yield "></div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["price_block_base_class", "price_block_modifiers", "price_block_additional_classes", "sidebar"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@droopler_theme/price-block/price-block.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  103 => 23,  98 => 21,  94 => 20,  90 => 19,  85 => 17,  81 => 16,  77 => 15,  71 => 12,  67 => 11,  64 => 10,  60 => 8,  58 => 7,  55 => 6,  53 => 5,  51 => 4,  49 => 3,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@droopler_theme/price-block/price-block.twig", "profiles/contrib/droopler/themes/custom/droopler_theme/src/components/price-block/price-block.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 3, "if" => 7);
        static $filters = array("escape" => 1, "default" => 3, "merge" => 8);
        static $functions = array("attach_library" => 1, "bem" => 11);

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['escape', 'default', 'merge'],
                ['attach_library', 'bem'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
